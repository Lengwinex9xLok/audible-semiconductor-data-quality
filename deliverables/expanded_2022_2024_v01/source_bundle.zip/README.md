# Reproduce the expanded historical review

Open powerbi/Audible.pbip in Desktop. The compressed embedded tables require no account connection.
Use the native PBIX in the accompanying deliverables for the saved data model.

With Python, pandas and numpy available:

    python reconcile_summaries.py
    python -W error::FutureWarning -m unittest discover -s expansion_v01 -p "test_expansion.py"

The first command verifies all period paths and annual/monthly compounding without network or writes.
The eight tests use fictional data. Full source hashes appear in SOURCE_SHA256.json; received result
hashes are in results/expansion_manifest.json. Tests do not verify licensed raw source prices or fills.

expansion_v01/run_expansion.py is the actual WRDS-side runner with the original independent project
and run paths. It reads existing hashed source/audit files and writes a fresh result directory; it
never queries WRDS. Complete raw-to-result replication requires those authorized originals, which
are intentionally absent. Do not change its paths to the group project or pull more data for dashboard review.
The old extraction scaffold remains in the repository and is attributed in docs/source_provenance.json.

Annual/monthly reports segment continuous capital and carried positions. Period-start stock weights drift.
Expanded quote results include two required locked quotes at zero recorded width; no actual zero-cost
execution is claimed. Strict-normal-only complete costs are unavailable; no quote/row is repaired or dropped.
The single crossed quote is unused for costs. No 2025 data were available in the same tables.

Each dashboard page has its own period selector. Page 2 annual bars always show all three years.
After drilling to a stock, select its desired reporting year separately. Empty dates remain blank.
Validation receipts record native UI checks and remaining student/instructor/source-review items.
Authoring history scripts document construction in the original workspace; edit paths before reuse.
