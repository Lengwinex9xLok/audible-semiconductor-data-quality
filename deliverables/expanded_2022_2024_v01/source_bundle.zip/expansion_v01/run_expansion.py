"""Run only against the already completed independent expansion, never pull data."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,runpy,sys,uuid,zipfile
sys.dont_write_bytecode=True
import pandas as pd,numpy as np
from expansion_core import expanded_evaluate
PROJECT=Path('/home/duke/lengwinex9x/audible_semiconductors_20261025/Audible-Semiconductor').resolve()
EXPAND=PROJECT/'data/semiconductors/expansion_runs/expanded_2022_2024_20261026T134704Z_af1be404'
SOURCE=EXPAND/'processed/stocks/2021-12-30_2024-12-31/stock_daily.csv'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 assert json.loads((PROJECT/'config/audible.json').read_text())['project']=='audible-semiconductors-v1'
 assert EXPAND.is_relative_to(PROJECT/'data/semiconductors/expansion_runs')
 protected={p:sha(p) for p in (PROJECT/'data/semiconductors').rglob('*') if p.is_file() and 'expansion_runs' not in p.parts}
 raw=EXPAND/'raw/stocks/wrds/2021-12-30_2024-12-31';rm=json.loads((raw/'manifest.json').read_text())
 assert rm['status']=='complete' and sha(raw/'manifest.json')=='2cebee170a49d888066b261d1d7207d03c8e8b4ec63c8ffb78a9b103e6427661'
 for r in rm['files']:assert sha(raw/r['name'])==r['sha256']
 audits=list((SOURCE.parent/'repro_audits').glob('*/audit_manifest.json'));assert len(audits)==1
 am=json.loads(audits[0].read_text());assert am['status']=='complete' and am['source_sha256']==sha(SOURCE)
 for name,value in am['outputs'].items():assert sha(audits[0].parent/name)==value['sha256']
 cal=pd.read_csv(audits[0].parent/'trading_calendar.csv').trading_date
 daily=pd.read_csv(SOURCE)
 assert len(daily)==7550 and daily.permno.nunique()==10 and len(cal)==755
 orig=PROJECT/'benchmark_v02/benchmark_core_v02.py'
 assert sha(orig)=='b4a585d9d911a0c9d22c20c92ede5d9c12db6b567099ff3439f33e583b226141'
 assert sha(Path(__file__).parent/'benchmark_core_v02.py')==sha(orig)
 core=runpy.run_path(str(orig));tables=expanded_evaluate(daily,cal,core)
 # Reproduce the original June result with the expanded aggregation code, without modifying it.
 june=PROJECT/'data/semiconductors/processed/stocks/2024-06-01_2024-06-30/stock_daily.csv'
 assert sha(june)=='5fecbfd21d39fe4ddf3cde1dd3d13e2cf194c2ca193f2d483cab7809d5e13b31'
 jd=pd.read_csv(june);jc=sorted(jd.date.unique());a=expanded_evaluate(jd,jc,core)[0];a=a.loc[a.period.eq('All')]
 ref=pd.read_csv(PROJECT/'data/semiconductors/benchmark_runs/benchmark_v02_20261026T023308Z_4245d86a/performance_summary.csv')
 for col in ['cumulative_return','cost_drag_return_difference','difference_from_always_long','entries','exits','average_invested_sleeve_share']:
  np.testing.assert_allclose(a[col],ref[col],atol=1e-12,rtol=0)
 dest=EXPAND/'benchmark_runs'/('expanded_v01_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ_')+uuid.uuid4().hex[:8]);dest.mkdir(parents=True,exist_ok=False)
 names=['performance_summary.csv','daily_portfolio_summary.csv','stock_performance_summary.csv','stock_daily_summary.csv','monthly_summary.csv','quote_exception_events.csv']
 for name,table in zip(names,tables):table.to_csv(dest/name,index=False,mode='x')
 # Reconcile CSV roundtrip and retain exact output hashes.
 summary=pd.read_csv(dest/names[0]);detail=pd.read_csv(dest/names[2])
 for row in summary.itertuples(index=False):
  sub=detail.loc[detail.period.eq(row.period)&detail.strategy.eq(row.strategy)&detail.cost_case.eq(row.cost_case)]
  assert np.isclose(sub.contribution_to_portfolio_return.sum(),row.cumulative_return,atol=1e-11,rtol=0)
 for p,h in protected.items():assert sha(p)==h
 manifest=dict(status='expanded_calculation_complete_review_required',created_at_utc=datetime.now(timezone.utc).isoformat(),analysis_years=[2022,2023,2024],requested_years=[2022,2023,2024,2025],unavailable_years_in_same_source=[2025],analysis_records=7530,warmup_records=20,source_records=7550,stocks=10,calendar_dates=755,holding_intervals=753,first_entry='2021-12-31',final_exit='2024-12-31',raw_pull_at_utc=rm['pulled_at_utc'],raw_manifest_sha256=sha(raw/'manifest.json'),source_sha256=sha(SOURCE),audit_manifest_sha256=sha(audits[0]),source_vendor_release='not recorded',code_sha256={p.name:sha(p) for p in Path(__file__).parent.glob('*.py')},original_v02_financial_engine_unchanged=True,june_v02_results_reproduced=True,quote_policy='Locked-inclusive quoted-width sensitivity: positive locked quotes have zero quoted half-width; crossed quotes are unusable for costs and permitted only when no entry/exit cost needs that quote. No rows dropped, swapped or imputed.',strict_normal_only_complete_cost_estimate_available=False,required_locked_quote_events=2,crossed_quote_cost_events=0,annual_monthly_definition='Segments of a continuous equal-initial-capital sleeve portfolio; no annual rebalance, forced liquidation or strategy reset. Stock contributions use period-start drifting wealth weights.',original_files_unchanged=len(protected),network_or_WRDS_queries=False,raw_prices_or_quotes_included=False,private_strategy_used=False,outputs={name:sha(dest/name) for name in names},table_rows={name:len(t) for name,t in zip(names,tables)},runtime=dict(python=sys.version.split()[0],pandas=pd.__version__),limitations=['Convenience universe selected in 2026, not historical index or survivorship-free sample','2024 June results were already seen; later or other years are additional historical checks, not prospective validation','No actual fills, intraday latency, fees, impact, taxes or cash yield','Same-source availability ended in 2024; no 2025 or 2026 profitability claim','Quotes include two required locked events with zero quoted width, not zero actual trading costs','No independent human/source verification of expanded results yet'])
 with (dest/'expansion_manifest.json').open('x') as f:json.dump(manifest,f,indent=2)
 archive=EXPAND/('summary_handoff_'+dest.name+'.zip')
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
  for name in names+['expansion_manifest.json']:z.write(dest/name,name)
 print(json.dumps(dict(status=manifest['status'],result_directory=str(dest),summary_zip=str(archive),zip_sha256=sha(archive),rows=manifest['table_rows'],original_files_unchanged=len(protected)),indent=2))
 print(summary[['period','strategy','cost_case','cumulative_return','cost_drag_return_difference','entries','exits']].to_string(index=False))
 return dest,archive
if __name__=='__main__':main()
