# Expanded time coverage protocol

Fixed before viewing expanded performance. The same-source check returned complete
2022-2024 years; 2025 was unavailable. Requesting 2022-2025 did not produce a fourth year.
Use 2021-12-30 and 2021-12-31 only as warmup/initial entry dates so all 753 analysis
trading dates in 2022-2024 are covered. Ten present-selected labels and dated IDs remain fixed.

Reuse the exact v02 sleeve_path, full-session lag, equal initial sleeves, zero cash yield,
0x/1x/2x cost multipliers and fixed final liquidation. Annual/monthly reports segment
one continuous portfolio; no yearly capital reset or rebalancing. Period contributions
use actual drifting wealth weights at each period start, not a fresh 10% allocation.

The original strict-normal June validator and June results are unchanged. Expanded
results use an explicitly labeled LOCKED-INCLUSIVE quoted-width sensitivity. Two entry/exit
costs need positive locked quotes; their formula width is zero, not a claim of free execution.
A crossed quote is never swapped, absolutized or treated as executable. Its observation
is retained only because neither strategy requires it for entry/exit cost. A required crossed
quote stops the calculation. All source records are preserved. The strict normal-only cost
estimate for the complete expanded path is unavailable, not silently certified.

These extra historical years share the 2026 convenience universe and the already-seen
June pilot. They are not a prospectively collected or survivorship-free holdout. No annualized
return, significance or risk-adjusted alpha claim is produced. New outcomes may contradict
the June conclusion. Publication must preserve the original June files as a dated pilot.
