from pathlib import Path
import pandas as pd,numpy as np,json,hashlib
r=Path(__file__).resolve().parent/'results'
s=pd.read_csv(r/'performance_summary.csv',dtype={'period':str});p=pd.read_csv(r/'daily_portfolio_summary.csv',dtype={'period':str});d=pd.read_csv(r/'stock_performance_summary.csv',dtype={'period':str});sp=pd.read_csv(r/'stock_daily_summary.csv',dtype={'period':str});m=pd.read_csv(r/'monthly_summary.csv')
k=['period','strategy','cost_case'];w=d.set_index(k+['ticker']).initial_portfolio_weight
x=sp.merge(d[k+['ticker','initial_portfolio_weight']],on=k+['ticker'],validate='many_to_one')
x=x.assign(weighted_wealth=x.wealth*x.initial_portfolio_weight)
a=x.groupby(k+['date'],as_index=False).agg(wealth=('weighted_wealth','sum'),entries=('entries','sum'),exits=('exits','sum'),invested_sleeve_share=('position','mean'))
b=p.merge(a,on=k+['date'],validate='one_to_one',suffixes=('_saved','_checked'))
assert len(b)==len(p)==9060
for c in ['wealth','entries','exits','invested_sleeve_share']:
 np.testing.assert_allclose(b[c+'_saved'],b[c+'_checked'],atol=1e-10,rtol=0,equal_nan=True)
for (strategy,cost),g in s.groupby(['strategy','cost_case']):
 total=g.loc[g.period.eq('All'),'cumulative_return'].iloc[0]
 assert np.isclose((1+g.loc[g.period.ne('All'),'cumulative_return']).prod()-1,total,atol=1e-12,rtol=0)
 sub=m.loc[m.strategy.eq(strategy)&m.cost_case.eq(cost)]
 assert np.isclose((1+sub.cumulative_return).prod()-1,total,atol=1e-12,rtol=0)
report=dict(status='expanded_local_hash_and_accounting_passed',portfolio_path_rows_reconciled=len(b),summary_cases=24,stock_summary_rows=240,monthly_rows=216,yearly_and_monthly_compounding='passed',raw_source_data_read_locally=False,human_independent_verification='pending for expanded results')
print(json.dumps(report,indent=2))
print(s.loc[s.cost_case.eq('quoted_spread_proxy'),['period','strategy','cumulative_return','average_invested_sleeve_share']].to_string(index=False))
