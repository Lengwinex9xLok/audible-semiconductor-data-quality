from pathlib import Path
from copy import deepcopy
import json,csv,math,uuid,shutil,hashlib
BASE=Path.cwd();OLD=BASE/'outputs/Audible-PowerBI-v07';R=BASE/'outputs/Audible-PowerBI-v08';DATA=BASE/'outputs/Audible-Expansion-v01/received'
assert not R.exists()
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
for n in ['Audible.Report','Audible.SemanticModel']:shutil.copytree(OLD/n,R/n,ignore=shutil.ignore_patterns('.pbi'))
shutil.copy2(OLD/'Audible.pbip',R/'Audible.pbip');shutil.copytree(DATA,R/'source_summaries')
manifest=read(DATA/'expansion_manifest.json')
for n,h in manifest['outputs'].items():assert hashlib.sha256((DATA/n).read_bytes()).hexdigest()==h
labels={'lagged_positive_return':'Public daily rule','always_long':'Always long'}
costs={'gross_zero_cost':'Gross (0x)','quoted_spread_proxy':'Quote proxy (1x)','double_spread_stress':'Wider stress (2x)'}
strings={'period','ticker','strategy','cost_case','date','entry_date','first_entry','final_exit','strategy_label','cost_label','case_id','period_label'}
def rows(n):
 with (DATA/n).open() as f:d=list(csv.DictReader(f))
 for r in d:
  for k,v in list(r.items()):
   if k not in strings:r[k]=None if v=='' else float(v)
  if 'strategy' in r:r['strategy_label']=labels[r['strategy']]
  if 'cost_case' in r:r['cost_label']=costs[r['cost_case']]
 return d
summary=rows('performance_summary.csv');paths=rows('daily_portfolio_summary.csv');stocks=rows('stock_performance_summary.csv');stockpaths=rows('stock_daily_summary.csv')
for r in stocks:r['difference_from_stock_always_long']=r['difference_from_always_long']
def ml(v,t):
 if v is None:return 'null'
 if t=='string':return '"'+str(v).replace('"','""')+'"'
 if t=='dateTime':return '#datetime('+','.join(map(str,[*map(int,v.split('-')),0,0,0]))+')'
 return repr(v)
def table(name,values,old=None):
 types={k:('dateTime' if k=='date' else 'string' if k in strings else 'int64' if k=='is_initial' else 'double') for k in values[0]}
 mt={'dateTime':'datetime','string':'text','int64':'Int64.Type','double':'number'}
 e='let\n Source = #table(type table ['+', '.join(k+' = '+mt[t] for k,t in types.items())+'], {\n'+',\n'.join('{'+', '.join(ml(r.get(k),t) for k,t in types.items())+'}' for r in values)+'\n })\nin Source'
 return dict(name=name,lineageTag=str(uuid.uuid4()),columns=[dict(name=k,dataType=t,sourceColumn=k,summarizeBy='none',lineageTag=str(uuid.uuid4()),**({'formatString':'MMM d, yyyy'} if t=='dateTime' else {})) for k,t in types.items()],partitions=[dict(name=name,mode='import',source=dict(type='m',expression=e.splitlines()))],measures=deepcopy(old.get('measures',[])) if old else [])
bim=read(R/'Audible.SemanticModel/model.bim');bim['model'].pop('cultures',None)
oldtables={t['name']:t for t in bim['model']['tables']}
new=[]
for name,values in [('Summary',summary),('Paths',paths),('StockSummary',stocks),('StockPaths',stockpaths)]:
 t=table(name,values,oldtables[name])
 for m in t['measures']:
  if m['name']=='Stock Contribution Note':m['expression']='"At its period-start sleeve weight, this stock contributes " & FORMAT(CALCULATE(SUM(StockSummary[contribution_to_portfolio_return]),StockSummary[strategy]="lagged_positive_return",StockSummary[cost_case]="quoted_spread_proxy")*100,"0.0000") & " percentage points to the selected-period 1x portfolio return."'
  e=m['expression'];e='\n'.join(e) if isinstance(e,list) else e
  m['expression']='CALCULATE(('+e+'),TREATAS({SELECTEDVALUE(PeriodSelector[period],"All")},'+name+'[period]))'
 new.append(t)
new.append(oldtables['CaseSelector'])
new.append(table('PeriodSelector',[{'period':'All','period_label':'Full 2022-2024'}]+[{'period':str(y),'period_label':str(y)} for y in [2022,2023,2024]]))
annual=table('AnnualSummary',[r for r in summary if r['period']!='All'])
for name,strategy in [('Annual Public Net','lagged_positive_return'),('Annual Passive Net','always_long')]:
 annual['measures'].append(dict(name=name,expression='VAR C=SELECTEDVALUE(CaseSelector[case_id],"quoted_spread_proxy") RETURN CALCULATE(MAX(AnnualSummary[cumulative_return]),AnnualSummary[strategy]="'+strategy+'",AnnualSummary[cost_case]=C)',formatString='0.00%;-0.00%;0.00%'))
new.append(annual);bim['model']['tables']=new
bim['model']['relationships']=[dict(name=str(uuid.uuid4()),fromTable=n,fromColumn='period',fromCardinality='many',toTable='PeriodSelector',toColumn='period',toCardinality='one',crossFilteringBehavior='oneDirection') for n in ['Summary','Paths','StockSummary','StockPaths']]
for a in bim['model'].get('annotations',[]):
 if a['name']=='PBI_QueryOrder':a['value']=json.dumps([t['name'] for t in new])
write(R/'Audible.SemanticModel/model.bim',bim)
PAGES=R/'Audible.Report/definition/pages'
def vp(pg,n):return PAGES/pg/'visuals'/n/'visual.json'
def save(pg,n,v):write(vp(pg,n),v)
def lit(v):return {'expr':{'Literal':{'Value':v}}}
def tl(v):return lit("'"+v.replace("'","''")+"'")
def field(t,n,kind='Measure'):return {kind:{'Expression':{'SourceRef':{'Entity':t}},'Property':n}}
def proj(t,n,kind='Measure',label=None):return dict(field=field(t,n,kind),queryRef=t+'.'+n,nativeQueryRef=n,active=True,**({'displayName':label} if label else {}))
def text(pg,n,lines,size=None):
 v=read(vp(pg,n));paras=v['visual']['objects']['general'][0]['properties']['paragraphs'];style=deepcopy(paras[0]['textRuns'][0].get('textStyle',{}))
 if size:style['fontSize']=str(size)+'pt'
 v['visual']['objects']['general'][0]['properties']['paragraphs']=[dict(textRuns=[dict(value=line,textStyle=style)]) for line in lines];save(pg,n,v)
def title(v,t):v['visual']['visualContainerObjects']['title'][0]['properties']['text']=tl(t)
# Per-page period controls, with explicit All fallback even if a slicer is cleared.
for pg in ['results','challenge','stock_detail']:
 v=read(vp('challenge','cost_selector'));s=json.dumps(v).replace('CaseSelector','PeriodSelector').replace('cost_label','period_label').replace('Quote proxy (1x)','Full 2022-2024');v=json.loads(s)
 v['name']='period_selector';v['position'].update(x=1260,y=140 if pg=='stock_detail' else 130,width=308,height=85,z=99,tabOrder=99);title(v,'Reporting period (this page)');save(pg,'period_selector',v)
 pgfile=PAGES/pg/'page.json';page=read(pgfile)
 # Chart selection must not disable or alter the period slicer; period slicer must filter the data visuals.
 page['visualInteractions']=[r for r in page.get('visualInteractions',[]) if r.get('target')!='period_selector'];write(pgfile,page)
text('results','headline',['Keep in research: performance changes sharply across years'],27)
text('results','scope',['2022-2024 | 10 fixed stocks | 753 holding intervals in the full period. Choose a year at right.','Equal initial sleeves; no annual rebalance. The signal and 0x/1x/2x financial rules are unchanged.'],13)
v=read(vp('results','scope'));v['position']['width']=1200;save('results','scope',v)
text('results','interpretation',['The full-period 1x result is -8.41%, but 2023 and 2024 are positive. A one-month loss is not a stable yearly finding.','Always-long has different exposure; its stronger full-period return is a descriptive comparison, not proof of alpha.'],13)
text('results','recommendation',['RECOMMENDATION: retain this public rule as research. Report all years and cost cases, including profitable years.','Three retrospective years with a 2026 convenience universe do not establish a deployable edge in 2026.'],13)
text('results','limits',['QUOTE LIMIT: this is a locked-inclusive quoted-width sensitivity; two trade events have zero recorded quote width, not zero execution cost.','One crossed quote is retained but unused for transaction costs. No rows are dropped or repaired. Fees, impact, latency and cash yield are omitted.','The same-source tables returned no 2025 records; no 2025-2026 performance is inferred.'],11)
text('results','breadcrumb',['FINTECH 590 / PROJECT AUDIBLE / EXPANDED HISTORICAL CHECK'],11)
text('results','label_2',['GROSS MINUS 1x RETURN (bps)'],10)
text('challenge','headline',['Positive years challenge a blanket failure claim'],27)
text('challenge','selection_scope',['The cost and period choices on this page affect the path, cards and table.','The annual chart always shows all three years under the selected cost case.'],11)
v=read(vp('challenge','selection_scope'));v['position']['width']=570;save('challenge','selection_scope',v)
text('challenge','counterargument',['STRONGEST COUNTEREVIDENCE','2023 earns +29.25% and 2024 +1.34% under the 1x proxy. In 2022 the rule loses less than always-long.','Those results challenge a blanket failure claim. Lower exposure, omitted cash yield and uncertain execution still limit a deployment inference.'],13)
text('challenge','exposure_note',['Annual paths are segments of one continuous portfolio. Year-end positions carry forward; capital weights drift and there is no yearly reset.','Gross-minus-proxy period return is not a cash-fee total; prior costs can change starting weights. Held share counts sleeves, not dollar exposure.'],12)
text('stock_detail','stock_scope',['Select a reporting period at right; this page has independent period and cost controls.','A stock year starts with its carried-over wealth; its portfolio weight may differ from 10%.'],12)
v=read(vp('stock_detail','stock_scope'));v['position']['width']=570;save('stock_detail','stock_scope',v)
text('stock_detail','stock_context',['WHY THIS VIEW','Inspect gains, losses, turnover and costs without deleting losing stocks.','The contribution sentence always uses the selected-period 1x case and its actual period-start weight.'],12)
text('stock_detail','stock_limits',['Quoted-width results include positive locked quotes at zero recorded width; execution costs remain unmeasured.','Return charts are historical. The 2026-selected universe and shared market exposure limit generalization.'],11)
for pg in ['results','challenge','stock_detail']:
 text(pg,'footer',['WRDS / legacy CRSP | 2022-2024 retrospective sample | Private coursework review | Original June pilot preserved'],10)
# Annual chart replaces the held-sleeve path; exposure remains in cards/table and definitions.
v=read(vp('results','cost_cases'));v['name']='sleeve_path';v['position']=read(vp('challenge','sleeve_path'))['position']
v['visual']['query']={'queryState':{'Category':{'projections':[proj('AnnualSummary','period','Column')]},'Y':{'projections':[proj('AnnualSummary','Annual Public Net',label='Public rule'),proj('AnnualSummary','Annual Passive Net',label='Always long')]}},'sortDefinition':{'sort':[{'field':field('AnnualSummary','period','Column'),'direction':'Ascending'}]}}
title(v,'Annual return: all years, selected cost case');save('challenge','sleeve_path',v)
# Automatic axes include current-period positive and negative data; common series share one value axis.
for pg in ['results','challenge','stock_detail']:
 for p in (PAGES/pg/'visuals').glob('*/visual.json'):
  v=read(p)
  if v['visual']['visualType'] in ['lineChart','clusteredBarChart']:
   for axis in v['visual'].get('objects',{}).get('valueAxis',[]):
    for k in ['start','end']:axis['properties'].pop(k,None)
   write(p,v)
# Keep fixed 1x contribution wording explicit.
v=read(vp('results','passive_comparison'));title(v,'Selected-period 1x stock contributions (percentage points)');save('results','passive_comparison',v)
# Remove any preparation-time stale docs by writing fresh current instructions.
(R/'README.md').write_text('''# Expanded 2022-2024 dashboard v08

Open Audible.pbip or the native saved PBIX when available. All summary tables are embedded.
The reporting-period selector on each page is independent; clearing it defaults measures to Full 2022-2024.
Select the same year on the stock-detail page after drilling if desired. A stock drill replaces the ticker filter.
Page 2 annual bars always display all three years under its cost selection. They ignore the period selector by design.

The full-period 1x return is negative, while 2023 and 2024 are positive. Read those as a conditional quoted-width
sensitivity, including two required locked-quote events at zero recorded width. The one crossed quote is not
needed for any cost event and is not repaired. No source records were dropped. No 2025 records were available
in the same source; this is not evidence about 2025 or 2026 trading performance.

Annual stock contributions use drifting period-start weights; full-period initial weights are 10%.
Annual/monthly paths segment one continuous portfolio with no annual reset or forced boundary trades.
The original June v07 and its files are preserved. Native verification is recorded separately.
''',encoding='utf-8')
write(R/'verification/build.json',dict(status='source_prepared_native_validation_pending',tables={t['name']:len(v) for t,v in [('Summary',summary),('Paths',paths),('StockSummary',stocks),('StockPaths',stockpaths)]},source_manifest_sha256=hashlib.sha256((DATA/'expansion_manifest.json').read_bytes()).hexdigest(),period_controls='independent per page; All fallback',annual_bar_scope='all three years; selected cost case'))
print(R)
