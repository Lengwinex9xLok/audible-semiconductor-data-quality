from pathlib import Path
import json,re,ast,zlib,base64,hashlib
p=Path('outputs/Audible-PowerBI-v08/Audible.SemanticModel/model.bim');before=p.read_bytes();m=json.loads(before)
mt={'string':'type text','dateTime':'type datetime','int64':'Int64.Type','double':'type number'}
counts={}
for t in m['model']['tables']:
 e=t['partitions'][0]['source']['expression'];e='\n'.join(e) if isinstance(e,list) else e
 rows=[]
 for line in e.splitlines():
  if not line.startswith('{'):continue
  line=re.sub(r'#datetime\((\d+),(\d+),(\d+),0,0,0\)',lambda x:repr(f'{int(x[1]):04d}-{int(x[2]):02d}-{int(x[3]):02d}'),line.rstrip(','))
  rows.append(ast.literal_eval('['+line[1:-1].replace('null','None')+']'))
 assert rows,t['name']
 data=json.dumps(rows,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
 compressor=zlib.compressobj(level=9,wbits=-15);compressed=compressor.compress(data)+compressor.flush()
 assert json.loads(zlib.decompress(compressed,wbits=-15))==rows
 b64=base64.b64encode(compressed).decode()
 cols=[c['sourceColumn'] for c in t['columns']]
 expr='let\n Rows = Json.Document(Binary.Decompress(Binary.FromText("'+b64+'", BinaryEncoding.Base64), Compression.Deflate)),\n Source = Table.FromRows(Rows, {'+', '.join(json.dumps(c) for c in cols)+'}),\n Typed = Table.TransformColumnTypes(Source, {'+', '.join('{'+json.dumps(c['sourceColumn'])+', '+mt[c['dataType']]+'}' for c in t['columns'])+'}, "en-US")\nin Typed'
 t['partitions'][0]['source']['expression']=expr.splitlines();counts[t['name']]=len(rows)
p.write_text(json.dumps(m,indent=2),encoding='utf-8')
record=dict(status='lossless_compressed_M_embedding_prepared',bytes_before=len(before),bytes_after=p.stat().st_size,rows_roundtrip_exact=counts,reason='Power BI project model JSON exceeded the native 10MB source-file limit; compression changes representation only',native_validation='pending')
Path('outputs/Audible-PowerBI-v08/verification/compressed_embedding.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record,indent=2))
