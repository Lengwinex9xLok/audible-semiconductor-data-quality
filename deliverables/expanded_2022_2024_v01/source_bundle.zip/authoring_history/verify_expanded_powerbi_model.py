from pathlib import Path
import json,re,base64,zlib,csv,math,hashlib,zipfile
r=Path('outputs/Audible-PowerBI-v08');src=Path('outputs/Audible-Expansion-v01/received')
m=json.loads((r/'Audible.SemanticModel/model.bim').read_text(encoding='utf-8-sig'))
files={'Summary':'performance_summary.csv','Paths':'daily_portfolio_summary.csv','StockSummary':'stock_performance_summary.csv','StockPaths':'stock_daily_summary.csv'};checks={}
for t in m['model']['tables']:
 e=t['partitions'][0]['source']['expression'];e='\n'.join(e) if isinstance(e,list) else e
 match=re.search(r'Binary.FromText\("([A-Za-z0-9+/=]+)"',e);assert match,t['name']
 values=json.loads(zlib.decompress(base64.b64decode(match[1]),wbits=-15));cols=[c['sourceColumn'] for c in t['columns']]
 rows=[dict(zip(cols,v)) for v in values];checks[t['name']]=len(rows)
 if t['name'] in files:
  with (src/files[t['name']]).open(newline='') as f:ref=list(csv.DictReader(f))
  assert len(rows)==len(ref)
  for a,b in zip(rows,ref):
   for k,v in b.items():
    actual=a[k]
    if actual is None:assert v==''
    elif isinstance(actual,(int,float)):assert abs(actual-float(v))<1e-12,(t['name'],k)
    else:assert actual==v,(t['name'],k,actual,v)
 if t['name'] in ['Paths','StockPaths']:
  for q in t['measures']:
   e=q['expression'];e='\n'.join(e) if isinstance(e,list) else e
   assert 'COUNTROWS' in e and 'BLANK()' in e
p=r/'Audible_Semiconductor_v08.pbix'
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None
 meta=json.loads(z.read('Report/definition/pages/pages.json'));assert len(meta['pageOrder'])==3
 for pg,n in [('challenge','return_path'),('stock_detail','stock_return_path')]:
  v=json.loads(z.read(f'Report/definition/pages/{pg}/visuals/{n}/visual.json'))
  assert v['visual']['objects']['categoryAxis'][0]['properties']['axisType']['expr']['Literal']['Value']=="'Scalar'"
 assert z.getinfo('DataModel').file_size>0
record=dict(status='embedded_model_matches_all_expanded_CSV_values',tables=checks,model_bytes=(r/'Audible.SemanticModel/model.bim').stat().st_size,blank_date_guards_present=True,PBIX_has_native_model_and_three_pages=True,continuous_date_axes_in_saved_PBIX=True,PBIX_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),PBIX_bytes=p.stat().st_size)
(r/'verification/embedded_model_validation.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record,indent=2))
