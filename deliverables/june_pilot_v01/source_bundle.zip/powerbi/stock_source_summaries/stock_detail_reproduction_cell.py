from pathlib import Path
import hashlib
import json

stock_project = Path('/home/duke/lengwinex9x/audible_semiconductors_20261025/Audible-Semiconductor').resolve()
assert json.loads((stock_project / 'config/audible.json').read_text())['project'] == 'audible-semiconductors-v1'
stock_run = stock_project / 'data/semiconductors/benchmark_runs/benchmark_v02_20261026T023308Z_4245d86a'
stock_receipt = json.loads((stock_run / 'benchmark_manifest.json').read_text())
assert stock_receipt['model'] == 'public_lagged_positive_return_v02'
stock_checks = [(stock_project / n, h) for n, h in stock_receipt['input_sha256'].items()]
stock_checks += [(stock_run / n, h) for n, h in stock_receipt['outputs'].items()]
stock_checks += [(stock_project / 'benchmark_v02' / n, h) for n, h in stock_receipt['code_sha256'].items()]
for stock_path, stock_expected in stock_checks:
    stock_path = stock_path.resolve()
    assert stock_path.is_relative_to(stock_project), 'Unexpected input location.'
    assert hashlib.sha256(stock_path.read_bytes()).hexdigest() == stock_expected, f'Changed file: {stock_path.name}'
print(json.dumps({'status': 'ready_for_stock_level_breakdown', 'verified_files': len(stock_checks), 'files_written': False, 'network_or_WRDS_queries': False}, indent=2))

"""Stock-level breakdown of the fixed public benchmark; no network or writes."""
import numpy as np
import pandas as pd

def compute_stock_detail(daily, calendar, core):
    panel, days = core['validate_panel'](daily, calendar)
    groups = list(panel.groupby('permno', sort=True))
    count = len(groups)
    summaries, paths = [], []
    for permno, part in groups:
        part = part.reset_index(drop=True)
        ticker = str(part['pilot_ticker'].iloc[0])
        for strategy in core['STRATEGIES']:
            for case, multiplier in core['COST_CASES'].items():
                sleeve = core['sleeve_path'](part, strategy, multiplier)
                summaries.append(dict(ticker=ticker, strategy=strategy,
                    cost_case=case, spread_multiplier=multiplier,
                    cumulative_return=float(sleeve['wealth'].iloc[-1]-1),
                    initial_portfolio_weight=1/count,
                    holding_intervals=len(sleeve),
                    first_entry=days[1].strftime('%Y-%m-%d'),
                    final_exit=days[-1].strftime('%Y-%m-%d'),
                    average_held_share=float(sleeve['position'].mean()),
                    entries=int(sleeve['entries'].sum()),
                    exits=int(sleeve['exits'].sum())))
                for row in sleeve.itertuples(index=False):
                    paths.append(dict(ticker=ticker, strategy=strategy,
                        cost_case=case, spread_multiplier=multiplier,
                        entry_date=pd.Timestamp(row.entry_date).strftime('%Y-%m-%d'),
                        date=pd.Timestamp(row.date).strftime('%Y-%m-%d'),
                        wealth=float(row.wealth), position=int(row.position),
                        entries=int(row.entries), exits=int(row.exits)))
    gross = {(s['ticker'],s['strategy']):s['cumulative_return'] for s in summaries if s['cost_case']=='gross_zero_cost'}
    passive = {(s['ticker'],s['cost_case']):s['cumulative_return'] for s in summaries if s['strategy']=='always_long'}
    summaries = [dict(s,
        cost_drag_return_difference=gross[(s['ticker'],s['strategy'])]-s['cumulative_return'],
        contribution_to_portfolio_return=s['initial_portfolio_weight']*s['cumulative_return'],
        difference_from_stock_always_long=s['cumulative_return']-passive[(s['ticker'],s['cost_case'])]) for s in summaries]
    return pd.DataFrame(summaries),pd.DataFrame(paths)

def reconcile_stock_detail(detail, paths, saved_summary, saved_paths):
    assert not detail.duplicated(['ticker','strategy','cost_case']).any()
    assert not paths.duplicated(['ticker','strategy','cost_case','date']).any()
    for ref in saved_summary.itertuples(index=False):
        s=detail.loc[detail.strategy.eq(ref.strategy)&detail.cost_case.eq(ref.cost_case)]
        assert len(s)==ref.stocks and s.ticker.nunique()==ref.stocks
        assert s.holding_intervals.eq(ref.holding_intervals).all()
        assert np.isclose(s.contribution_to_portfolio_return.sum(),ref.cumulative_return,atol=1e-12,rtol=0)
        assert np.isclose(s.average_held_share.mean(),ref.average_invested_sleeve_share,atol=1e-12,rtol=0)
        assert np.isclose(s.cost_drag_return_difference.mean(),ref.cost_drag_return_difference,atol=1e-12,rtol=0)
        assert np.isclose(s.difference_from_stock_always_long.mean(),ref.difference_from_always_long,atol=1e-12,rtol=0)
        assert s.entries.sum()==ref.entries and s.exits.sum()==ref.exits
    for ref in saved_paths.itertuples(index=False):
        p=paths.loc[paths.strategy.eq(ref.strategy)&paths.cost_case.eq(ref.cost_case)&paths.date.eq(ref.date)]
        assert len(p)==detail.ticker.nunique()
        assert np.isclose(p.wealth.mean(),ref.wealth,atol=1e-12,rtol=0)
        assert np.isclose(p.position.mean(),ref.invested_sleeve_share,atol=1e-12,rtol=0)
        assert p.entries.sum()==ref.entries and p.exits.sum()==ref.exits
    return dict(summary_cases_checked=len(saved_summary),portfolio_dates_checked=len(saved_paths))

# Read the already-verified source files; reuse the unchanged public model.
stock_source = stock_project / 'data/semiconductors/processed/stocks/2024-06-01_2024-06-30/stock_daily.csv'
stock_calendar_names = [n for n in stock_receipt['input_sha256'] if n.endswith('/trading_calendar.csv')]
assert len(stock_calendar_names) == 1
stock_core_path = stock_project / 'benchmark_v02/benchmark_core_v02.py'
assert hashlib.sha256(stock_core_path.read_bytes()).hexdigest() == 'b4a585d9d911a0c9d22c20c92ede5d9c12db6b567099ff3439f33e583b226141'
stock_core_namespace = {'__name__': 'audible_stock_detail_core'}
exec(compile(stock_core_path.read_text(encoding='utf-8-sig'), str(stock_core_path), 'exec'), stock_core_namespace)
stock_daily = pd.read_csv(stock_source)
stock_calendar = pd.read_csv(stock_project / stock_calendar_names[0])['trading_date']
stock_saved_summary = pd.read_csv(stock_run / 'performance_summary.csv')
stock_saved_paths = pd.read_csv(stock_run / 'daily_portfolio_summary.csv')
stock_detail_summary, stock_detail_paths = compute_stock_detail(stock_daily, stock_calendar, stock_core_namespace)
assert len(stock_detail_summary) == 60 and len(stock_detail_paths) == 1020
stock_reconciliation = reconcile_stock_detail(stock_detail_summary, stock_detail_paths, stock_saved_summary, stock_saved_paths)
for stock_path, stock_expected in stock_checks:
    assert hashlib.sha256(stock_path.read_bytes()).hexdigest() == stock_expected
print(json.dumps({'status': 'stock_level_in_memory_reconciliation_passed', 'stocks': int(stock_detail_summary.ticker.nunique()), 'summary_rows': len(stock_detail_summary), 'stock_path_rows': len(stock_detail_paths), **stock_reconciliation, 'files_written': False, 'network_or_WRDS_queries': False, 'human_independent_verification': 'pending'}, indent=2))
print(stock_detail_summary.loc[stock_detail_summary.strategy.eq('lagged_positive_return') & stock_detail_summary.cost_case.eq('quoted_spread_proxy'), ['ticker','cumulative_return','cost_drag_return_difference','contribution_to_portfolio_return','entries','exits']].sort_values('ticker').to_string(index=False, float_format=lambda x: f'{x:.8f}'))
