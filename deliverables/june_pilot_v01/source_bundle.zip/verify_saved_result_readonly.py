"""Paste into the independent Audible notebook. Read-only saved-result audit."""
from pathlib import Path
import hashlib
import json
import numpy as np
import pandas as pd

project_root = Path.cwd().resolve()
assert json.loads((project_root / 'config/audible.json').read_text())['project'] == 'audible-semiconductors-v1'
run_dir = project_root / 'data/semiconductors/benchmark_runs/benchmark_v02_20261026T023308Z_4245d86a'
assert run_dir.is_dir(), 'Stop: use the exact completed benchmark output directory.'
manifest = json.loads((run_dir / 'benchmark_manifest.json').read_text())
assert manifest['status'] == 'computed_human_review_required'
assert manifest['model'] == 'public_lagged_positive_return_v02'
assert manifest['source_rows'] == 190 and manifest['holding_intervals_per_stock'] == 17
assert set(manifest['outputs']) == {'performance_summary.csv', 'daily_portfolio_summary.csv'}

def file_hash(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

for relative, expected in manifest['input_sha256'].items():
    path = (project_root / relative).resolve()
    assert path.is_relative_to(project_root), 'Unexpected input path.'
    assert file_hash(path) == expected, f'Changed input: {relative}'
for name, expected in manifest['outputs'].items():
    assert file_hash(run_dir / name) == expected, f'Changed saved result: {name}'
for name, expected in manifest['code_sha256'].items():
    assert Path(name).name == name
    assert file_hash(project_root / 'benchmark_v02' / name) == expected, f'Changed benchmark code: {name}'

summary = pd.read_csv(run_dir / 'performance_summary.csv')
paths = pd.read_csv(run_dir / 'daily_portfolio_summary.csv')
assert len(summary) == 6 and len(paths) == 102
assert not summary.duplicated(['strategy', 'cost_case']).any()
assert set(summary['strategy']) == {'lagged_positive_return', 'always_long'}
assert set(summary['cost_case']) == {'gross_zero_cost', 'quoted_spread_proxy', 'double_spread_stress'}
assert summary['stocks'].eq(10).all()
assert summary['first_entry'].eq('2024-06-04').all() and summary['final_exit'].eq('2024-06-28').all()
keys = summary.set_index(['strategy', 'cost_case'])
checked = []
for row in summary.itertuples(index=False):
    part = paths.loc[paths['strategy'].eq(row.strategy) & paths['cost_case'].eq(row.cost_case)].sort_values('date')
    assert len(part) == 17 and part['date'].nunique() == 17
    assert np.isfinite(part['wealth']).all() and part['wealth'].gt(0).all()
    assert part['invested_sleeve_share'].between(0, 1).all()
    assert (part[['entries', 'exits']] >= 0).all().all()
    assert np.isclose(part['wealth'].iloc[-1] - 1, row.cumulative_return, atol=1e-12, rtol=0)
    assert part['entries'].sum() == row.entries == row.exits == part['exits'].sum()
    assert np.isclose(part['invested_sleeve_share'].mean(), row.average_invested_sleeve_share, atol=1e-12, rtol=0)
    gross = keys.loc[(row.strategy, 'gross_zero_cost'), 'cumulative_return']
    passive = keys.loc[('always_long', row.cost_case), 'cumulative_return']
    assert np.isclose(gross - row.cumulative_return, row.cost_drag_return_difference, atol=1e-12, rtol=0)
    assert np.isclose(row.cumulative_return - passive, row.difference_from_always_long, atol=1e-12, rtol=0)
    invested_intervals = part['invested_sleeve_share'].sum() * 10
    assert np.isclose(invested_intervals, round(invested_intervals), atol=1e-9, rtol=0)
    checked.append(dict(strategy=row.strategy, cost_case=row.cost_case,
        return_pct=row.cumulative_return * 100,
        cost_drag_bps=row.cost_drag_return_difference * 10000,
        relative_to_always_long_pp=row.difference_from_always_long * 100,
        entries=row.entries, exits=row.exits,
        invested_stock_intervals=int(round(invested_intervals))))

print(json.dumps(dict(status='saved_result_accounting_checks_passed',
    input_hashes_verified=len(manifest['input_sha256']), output_hashes_verified=2,
    summary_rows=6, aggregate_path_rows=102, files_written=False,
    network_or_WRDS_queries=False, human_independent_verification='still pending'), indent=2))
print(pd.DataFrame(checked).to_string(index=False, float_format=lambda x: f'{x:.6f}'))
