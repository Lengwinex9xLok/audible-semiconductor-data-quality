from pathlib import Path
import re,json
from xml.sax.saxutils import escape
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,PageBreak,Preformatted,KeepTogether
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.lib import colors
from pypdf import PdfReader
ROOT=Path(__file__).resolve().parent
D=ROOT/'documents'
s=getSampleStyleSheet()
s.add(ParagraphStyle(name='MemoTitle',fontName='Helvetica-Bold',fontSize=18,leading=21,spaceAfter=9,textColor=colors.black))
s.add(ParagraphStyle(name='MemoBody',fontName='Helvetica',fontSize=10.5,leading=14,spaceAfter=8))
s.add(ParagraphStyle(name='MemoHead',fontName='Helvetica-Bold',fontSize=11.5,leading=15,spaceBefore=5,spaceAfter=7))
s.add(ParagraphStyle(name='MemoMeta',fontName='Helvetica',fontSize=9.2,leading=12,spaceAfter=10,textColor=colors.HexColor('#444444')))
s.add(ParagraphStyle(name='MemoSmall',fontName='Helvetica',fontSize=8.5,leading=11,spaceAfter=7))
s.add(ParagraphStyle(name='MemoCode',fontName='Courier',fontSize=8.5,leading=12,spaceAfter=10))
def foot(c,doc):
 c.setFont('Helvetica',8);c.setFillColor(colors.HexColor('#666666'))
 c.drawString(50,31,'Project Audible  |  June 2024 pilot')
 c.drawRightString(562,31,str(doc.page))
def p(text,style='MemoBody'):return Paragraph(escape(text).replace('\n','<br/>'),s[style])
def render(name,technical=False):
 text=(D/(name+'.txt')).read_text(encoding='utf-8-sig').strip()
 lines=text.split('\n');story=[p(lines[0],'MemoTitle'),p('  |  '.join(lines[1:4]),'MemoMeta')]
 content='\n'.join(lines[4:]).strip()
 heads={'The June evidence','The strongest objection','What would change the decision','Purpose and source','Data quality and preservation','Rule and accounting','Why these choices','Reproduction and dashboard','Checks and limits','Attribution and audit trail'}
 if not technical:content=content.replace('The strongest objection','===PAGE===\nThe strongest objection')
 for block in re.split(r'\n\s*\n',content):
  if block.startswith('===PAGE==='):
   story.append(PageBreak());block=block.removeprefix('===PAGE===').strip()
  if not block:continue
  ls=block.splitlines()
  if ls[0] in heads:
   story.append(p(ls[0],'MemoHead'));block='\n'.join(ls[1:]).strip()
   if not block:continue
  if block.startswith('Cost assumption'):
   table=Table([['Cost assumption','Public rule','Always long'],['Gross with zero cost','0.1631%','4.8225%'],['Quoted-width proxy','-0.0380%','4.7781%'],['Double-width stress','-0.2386%','4.7338%']],colWidths=[280,110,122],hAlign='LEFT')
   table.setStyle(TableStyle([('FONTNAME',(0,0),(-1,0),'Helvetica-Bold'),('FONTNAME',(0,1),(-1,-1),'Helvetica'),('FONTSIZE',(0,0),(-1,-1),10),('ALIGN',(1,0),(-1,-1),'RIGHT'),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7),('LINEBELOW',(0,0),(-1,0),.5,colors.HexColor('#888888')),('LINEBELOW',(0,-1),(-1,-1),.4,colors.HexColor('#bbbbbb'))]))
   story.extend([table,Spacer(1,10)])
  elif block.startswith('F(d)'):story.append(Preformatted(block,s['MemoCode']))
  else:story.append(p(block,'MemoSmall' if block.startswith('Evidence:') else 'MemoBody'))
 doc=SimpleDocTemplate(str(D/(name+'.pdf')),pagesize=(612,792),leftMargin=50,rightMargin=50,topMargin=45,bottomMargin=47,title=lines[0],author='Loki Ziye')
 doc.build(story,onFirstPage=foot,onLaterPages=foot)
 n=len(PdfReader(D/(name+'.pdf')).pages)
 assert n==(3 if technical else 2),(name,n)
 return {'file':name+'.pdf','pages':n,'words':len(text.split())}
print(json.dumps([render('position_memo'),render('technical_memo',True)],indent=2))
