"""Read the exact existing June pilot; write only a fresh benchmark output folder."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,platform,uuid,sys
sys.dont_write_bytecode=True
import pandas as pd
from benchmark_core_v02 import evaluate,COST_CASES
SOURCE_HASH='5fecbfd21d39fe4ddf3cde1dd3d13e2cf194c2ca193f2d483cab7809d5e13b31'
AUDIT_HASH='da03890fea30b2578c8fa1178bc5c10f0375d84086d123e52aad768272ce9e46'
TICKERS={'ADI','AMAT','AMD','INTC','KLAC','LRCX','MU','NVDA','QCOM','TXN'}
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def load_verified(project):
    project=Path(project).resolve()
    settings=project/'config/audible.json'
    if not settings.is_file() or json.loads(settings.read_text())['project']!='audible-semiconductors-v1':
        raise ValueError('Choose the independent Audible project root, not the group checkout')
    root=project/'data/semiconductors';processed=root/'processed/stocks/2024-06-01_2024-06-30'
    source=processed/'stock_daily.csv'
    if not source.is_file() or digest(source)!=SOURCE_HASH:
        raise ValueError('Existing June source does not match the saved handoff; stop, do not pull/rebuild')
    audits=[p for p in (processed/'repro_audits').glob('*/audit_manifest.json') if digest(p)==AUDIT_HASH]
    if len(audits)!=1:raise ValueError('Exactly one original matching audit receipt is required')
    manifest_path=audits[0];manifest=json.loads(manifest_path.read_text());audit=manifest_path.parent
    if manifest['status']!='complete' or manifest['source_sha256']!=SOURCE_HASH or manifest['window']!=['2024-06-01','2024-06-30']:
        raise ValueError('Audit receipt is incomplete or inconsistent')
    paths=[source,manifest_path,settings]
    for name in ['trading_calendar.csv','quality_summary.json']:
        p=audit/name
        if digest(p)!=manifest['outputs'][name]['sha256']:raise ValueError('Changed audit evidence: '+name)
        paths.append(p)
    summary=json.loads((audit/'quality_summary.json').read_text())
    if summary['rows']!=190 or summary['securities']!=10 or summary['calendar_exception_records']!=0 or summary['quote_status_counts']!={'NORMAL':190}:
        raise ValueError('This fixed pilot requires the original complete, normal-quote June sample')
    daily=pd.read_csv(source);calendar=pd.read_csv(audit/'trading_calendar.csv')['trading_date']
    if len(daily)!=190 or daily['permno'].nunique()!=10 or set(daily['pilot_ticker'])!=TICKERS or len(calendar)!=19:
        raise ValueError('Unexpected sample dimensions or stock labels')
    for c in ['core_flags','diagnostic_flags']:
        if daily[c].fillna('').astype(str).str.len().gt(0).any():raise ValueError('Flagged pilot rows require review')
    protected={str(p.relative_to(project)):digest(p) for p in paths}
    return root,daily,calendar,protected

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project-root',type=Path,default=Path(__file__).resolve().parent.parent)
    parser.add_argument('--check-only',action='store_true')
    args=parser.parse_args();project=args.project_root.resolve()
    root,daily,calendar,protected=load_verified(project)
    summary,paths=evaluate(daily,calendar)
    for name,h in protected.items():
        if digest(project/name)!=h:raise ValueError('Existing input changed: '+name)
    if args.check_only:
        print(json.dumps(dict(status='input_and_calculation_check_complete',rows=190,stocks=10,trading_dates=19,
            holding_intervals_per_stock=17,files_written=False,network_or_WRDS_queries=False),indent=2));return
    destination=root/'benchmark_runs'/('benchmark_v02_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ_')+uuid.uuid4().hex[:8])
    destination.mkdir(parents=True,exist_ok=False)
    summary.to_csv(destination/'performance_summary.csv',index=False,mode='x')
    paths.to_csv(destination/'daily_portfolio_summary.csv',index=False,mode='x')
    record=dict(status='computed_human_review_required',created_at_utc=datetime.now(timezone.utc).isoformat(),
        model='public_lagged_positive_return_v02',source_rows=190,trading_dates=19,holding_intervals_per_stock=17,
        input_sha256=protected,source_files_unchanged=True,row_level_prices_included=False,
        private_strategy_used=False,network_or_WRDS_queries=False,python=platform.python_version(),pandas=pd.__version__,
        cost_cases=COST_CASES,code_sha256={p.name:digest(p) for p in Path(__file__).parent.glob('*.py')},
        outputs={p.name:digest(p) for p in destination.glob('*.csv')},
        limitations=['One-month hindsight-selected pilot; not a statistical profitability finding',
          'Quoted-width multipliers applied to a RET wealth reference; not actual fills',
          'Historical data availability timestamps and execution delay are not measured',
          'Fees, impact, taxes and cash interest are omitted; no leverage or shorting',
          'No annualization, significance test or risk-adjusted alpha claim; source acceptance pending'])
    with (destination/'benchmark_manifest.json').open('x',encoding='utf-8') as f:json.dump(record,f,indent=2)
    print('New independent output:',destination)
    print(summary.to_string(index=False))
    print('Review this pilot before drawing a conclusion or transferring licensed derived results.')
if __name__=='__main__':main()
