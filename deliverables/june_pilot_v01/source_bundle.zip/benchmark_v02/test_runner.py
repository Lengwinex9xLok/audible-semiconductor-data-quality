"""Fictional filesystem tests for immutable inputs and fresh output directories."""
import sys,unittest,tempfile,json,io
from pathlib import Path
from contextlib import redirect_stdout
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parent))
import pandas as pd
import run_pilot as runner

class RunnerTests(unittest.TestCase):
    def setUp(self):
        self.test_base=(Path(__file__).resolve().parent/'.test-tmp').resolve();self.test_base.mkdir(exist_ok=True)
        self.temp=tempfile.TemporaryDirectory(dir=self.test_base);self.root=Path(self.temp.name).resolve()
        assert self.root.is_relative_to(self.test_base)
        (self.root/'config').mkdir();(self.root/'config/audible.json').write_text(json.dumps({'project':'audible-semiconductors-v1'}))
        self.processed=self.root/'data/semiconductors/processed/stocks/2024-06-01_2024-06-30';self.processed.mkdir(parents=True)
        dates=pd.bdate_range('2024-06-03','2024-06-28').difference(pd.DatetimeIndex(['2024-06-19']))
        rows=[dict(permno=i+1,pilot_ticker=t,date=d.strftime('%Y-%m-%d'),ret=.01 if j%2==0 else -.002,bid=99,ask=101,core_flags='',diagnostic_flags='') for i,t in enumerate(sorted(runner.TICKERS)) for j,d in enumerate(dates)]
        self.source=self.processed/'stock_daily.csv';pd.DataFrame(rows).to_csv(self.source,index=False)
        self.audit=self.processed/'repro_audits/FICTIONAL';self.audit.mkdir(parents=True)
        pd.DataFrame({'trading_date':dates}).to_csv(self.audit/'trading_calendar.csv',index=False)
        (self.audit/'quality_summary.json').write_text(json.dumps({'rows':190,'securities':10,'calendar_exception_records':0,'quote_status_counts':{'NORMAL':190}}))
        manifest=dict(status='complete',source_sha256=runner.digest(self.source),window=['2024-06-01','2024-06-30'],outputs={n:{'sha256':runner.digest(self.audit/n)} for n in ['trading_calendar.csv','quality_summary.json']})
        (self.audit/'audit_manifest.json').write_text(json.dumps(manifest))
        self.source_patch=patch.object(runner,'SOURCE_HASH',runner.digest(self.source));self.audit_patch=patch.object(runner,'AUDIT_HASH',runner.digest(self.audit/'audit_manifest.json'))
        self.source_patch.start();self.audit_patch.start()
    def tearDown(self):
        self.audit_patch.stop();self.source_patch.stop()
        assert self.root.resolve().is_relative_to(self.test_base)
        self.temp.cleanup()
    def invoke(self,*args):
        with patch.object(sys,'argv',['run_pilot.py','--project-root',str(self.root),*args]),redirect_stdout(io.StringIO()):runner.main()
    def test_check_only_writes_nothing(self):
        before={str(p.relative_to(self.root)):runner.digest(p) for p in self.root.rglob('*') if p.is_file()}
        self.invoke('--check-only')
        after={str(p.relative_to(self.root)):runner.digest(p) for p in self.root.rglob('*') if p.is_file()}
        self.assertEqual(before,after)
    def test_two_runs_create_two_new_outputs_and_preserve_inputs(self):
        before=runner.digest(self.source);self.invoke();self.invoke()
        dirs=list((self.root/'data/semiconductors/benchmark_runs').iterdir());self.assertEqual(len(dirs),2)
        self.assertEqual(before,runner.digest(self.source))
        for d in dirs:
            r=json.loads((d/'benchmark_manifest.json').read_text());self.assertEqual(r['status'],'computed_human_review_required')
            self.assertEqual(len(pd.read_csv(d/'performance_summary.csv')),6)
            self.assertEqual(len(pd.read_csv(d/'daily_portfolio_summary.csv')),102)
    def test_changed_source_rejected(self):
        self.source.write_bytes(self.source.read_bytes()+b'\n')
        with self.assertRaises(ValueError):self.invoke('--check-only')
    def test_wrong_project_rejected(self):
        (self.root/'config/audible.json').write_text(json.dumps({'project':'group-project'}))
        with self.assertRaises(ValueError):self.invoke('--check-only')
    def test_changed_calendar_rejected(self):
        (self.audit/'trading_calendar.csv').write_text('trading_date\n2024-06-03\n')
        with self.assertRaises(ValueError):self.invoke('--check-only')
if __name__=='__main__':unittest.main(verbosity=2)
