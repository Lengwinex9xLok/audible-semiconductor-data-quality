"""Fictional accounting and chronology tests; never read market data."""
import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import pandas as pd
import numpy as np
from benchmark_core_v02 import evaluate,validate_panel,sleeve_path

def fixture(returns=None):
    returns=[.03,.04,.01,.02] if returns is None else returns
    dates=pd.bdate_range('2024-01-02',periods=len(returns))
    d=pd.DataFrame({'permno':1,'pilot_ticker':'TEST','date':dates,'ret':returns,'bid':99.,'ask':101.})
    return d,dates

class AccountingTests(unittest.TestCase):
    def test_evaluate_does_not_use_frame_setitem(self):
        from unittest.mock import patch
        d, cal = fixture()
        with patch.object(pd.DataFrame, '__setitem__', side_effect=AssertionError('Frame assignment used')):
            summary, paths = evaluate(d, cal)
        self.assertEqual(len(summary), 6)

    def test_manual_continuous_hold(self):
        d,cal=fixture();s,p=evaluate(d,cal)
        r=s[s.strategy.eq('lagged_positive_return')].set_index('cost_case')
        self.assertAlmostEqual(r.loc['gross_zero_cost','cumulative_return'],.0302,12)
        self.assertAlmostEqual(r.loc['quoted_spread_proxy','cumulative_return'],.0098,12)
        self.assertAlmostEqual(r.loc['double_spread_stress','cumulative_return'],-.0102,12)
        self.assertEqual(r.loc['quoted_spread_proxy','entries'],1)
        self.assertEqual(r.loc['quoted_spread_proxy','exits'],1)
    def test_flat_cash_pays_no_cost(self):
        d,cal=fixture([-.1,-.1,.1,.2]);s,_=evaluate(d,cal)
        r=s[s.strategy.eq('lagged_positive_return')]
        self.assertTrue(r.cumulative_return.eq(0).all())
        self.assertTrue(r.entries.eq(0).all())
    def test_zero_signal_is_cash(self):
        d,cal=fixture([0,0,.1,.2]);s,_=evaluate(d,cal)
        self.assertTrue(s.loc[s.strategy.eq('lagged_positive_return'),'cumulative_return'].eq(0).all())
    def test_lag_does_not_use_entry_day_return(self):
        d,cal=fixture([.1,-.1,.2,.3]);d,_=validate_panel(d,cal)
        p=sleeve_path(d,'lagged_positive_return',0)
        self.assertEqual(p.position.tolist(),[1,0])
        self.assertAlmostEqual(p.wealth.iloc[-1],1.2)
    def test_future_mutation_does_not_change_position(self):
        d,cal=fixture();d,_=validate_panel(d,cal)
        a=sleeve_path(d,'lagged_positive_return',1)
        d.loc[3,'ret']=-.5
        b=sleeve_path(d,'lagged_positive_return',1)
        self.assertEqual(a.position.tolist(),b.position.tolist())
        self.assertEqual(a.wealth.iloc[0],b.wealth.iloc[0])
    def test_reentry_counts(self):
        d,cal=fixture([.1,-.1,.1,-.1,.01,.02]);d,_=validate_panel(d,cal)
        p=sleeve_path(d,'lagged_positive_return',1)
        self.assertEqual(p.position.tolist(),[1,0,1,0])
        self.assertEqual(int(p.entries.sum()),2);self.assertEqual(int(p.exits.sum()),2)
    def test_wealth_is_equal_initial_capital_not_daily_rebalanced(self):
        a,cal=fixture([.1,.1,1.,0]);b,_=fixture([.1,.1,0,1.]);b['permno']=2;b['pilot_ticker']='OTHER'
        s,_=evaluate(pd.concat([a,b]),cal)
        self.assertAlmostEqual(s.loc[(s.strategy=='always_long')&(s.cost_case=='gross_zero_cost'),'cumulative_return'].iloc[0],1.)
    def test_original_dataframe_unchanged(self):
        d,cal=fixture();old=d.copy(deep=True);evaluate(d,cal);pd.testing.assert_frame_equal(d,old)
    def test_all_cases_and_same_window(self):
        d,cal=fixture();s,p=evaluate(d,cal)
        self.assertEqual(len(s),6);self.assertEqual(len(p),12)
        self.assertEqual(s.holding_intervals.unique().tolist(),[2])
        self.assertTrue(s.entries.eq(s.exits).all())
    def test_duplicate_rejected(self):
        d,cal=fixture()
        with self.assertRaises(ValueError):evaluate(pd.concat([d,d.iloc[[0]]]),cal)
    def test_missing_stock_date_rejected(self):
        d,cal=fixture()
        with self.assertRaises(ValueError):evaluate(d.iloc[1:],cal)
    def test_crossed_or_locked_quote_rejected(self):
        for ask in [98.,99.]:
            d,cal=fixture();d.loc[0,'ask']=ask
            with self.assertRaises(ValueError):evaluate(d,cal)
    def test_missing_code_and_nan_rejected(self):
        for value in [-66.,-1.,np.nan]:
            d,cal=fixture();d.loc[0,'ret']=value
            with self.assertRaises(ValueError):evaluate(d,cal)
    def test_nonpositive_quote_rejected(self):
        d,cal=fixture();d.loc[0,'bid']=0
        with self.assertRaises(ValueError):evaluate(d,cal)
    def test_unsorted_calendar_rejected(self):
        d,cal=fixture()
        with self.assertRaises(ValueError):evaluate(d,cal[::-1])
    def test_cost_haircut_domain_rejected(self):
        d,cal=fixture();d,_=validate_panel(d,cal)
        with self.assertRaises(ValueError):sleeve_path(d,'always_long',100.)
    def test_ambiguous_identity_rejected(self):
        d,cal=fixture();d.loc[0,'pilot_ticker']='OTHER'
        with self.assertRaises(ValueError):evaluate(d,cal)

if __name__=='__main__':unittest.main(verbosity=2)
