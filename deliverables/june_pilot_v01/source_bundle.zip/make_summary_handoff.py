"""Paste into the independent Audible notebook to export aggregate results only."""
from pathlib import Path
from datetime import datetime, timezone
from decimal import Decimal as D
from zipfile import ZipFile, ZIP_DEFLATED
import csv
import hashlib
import io
import json
import uuid

RUN_NAME = 'benchmark_v02_20261026T023308Z_4245d86a'
CSV_NAMES = {'performance_summary.csv', 'daily_portfolio_summary.csv'}

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def close(a, b):
    return abs(D(str(a)) - D(str(b))) <= D('1e-12')

def build_handoff(project_root):
    project_root = Path(project_root).resolve()
    assert json.loads((project_root / 'config/audible.json').read_text())['project'] == 'audible-semiconductors-v1'
    run_dir = project_root / 'data/semiconductors/benchmark_runs' / RUN_NAME
    manifest_path = run_dir / 'benchmark_manifest.json'
    original_manifest_hash = digest(manifest_path)
    manifest = json.loads(manifest_path.read_text())
    assert manifest['status'] == 'computed_human_review_required'
    assert manifest['model'] == 'public_lagged_positive_return_v02'
    assert manifest['source_rows'] == 190 and manifest['trading_dates'] == 19
    assert manifest['holding_intervals_per_stock'] == 17
    assert manifest['private_strategy_used'] is False
    assert set(manifest['outputs']) == CSV_NAMES
    for relative, expected in manifest['input_sha256'].items():
        path = (project_root / relative).resolve()
        assert path.is_relative_to(project_root), 'Unexpected input path.'
        assert digest(path) == expected, f'Changed input: {relative}'
    for name, expected in manifest['code_sha256'].items():
        assert Path(name).name == name
        assert digest(project_root / 'benchmark_v02' / name) == expected, f'Changed code: {name}'
    payload = {name: (run_dir / name).read_bytes() for name in CSV_NAMES}
    for name, data in payload.items():
        assert hashlib.sha256(data).hexdigest() == manifest['outputs'][name], f'Changed output: {name}'
    tables = {name: list(csv.DictReader(io.StringIO(data.decode('utf-8-sig')))) for name, data in payload.items()}
    summary = tables['performance_summary.csv']
    paths = tables['daily_portfolio_summary.csv']
    assert len(summary) == 6 and len(paths) == 102
    forbidden = {'permno', 'pilot_ticker', 'bid', 'ask', 'prc', 'ret', 'retx', 'source_file', 'source_row'}
    assert all(not (set(rows[0]) & forbidden) for rows in tables.values())
    keys = {(r['strategy'], r['cost_case']): r for r in summary}
    assert len(keys) == 6
    expected_keys = {(s, c) for s in ['lagged_positive_return', 'always_long']
                     for c in ['gross_zero_cost', 'quoted_spread_proxy', 'double_spread_stress']}
    assert set(keys) == expected_keys
    for row in summary:
        part = sorted([r for r in paths if r['strategy'] == row['strategy'] and r['cost_case'] == row['cost_case']], key=lambda r: r['date'])
        assert len(part) == 17 and len({r['date'] for r in part}) == 17
        assert int(row['stocks']) == 10
        assert close(D(part[-1]['wealth']) - 1, row['cumulative_return'])
        assert sum(int(r['entries']) for r in part) == int(row['entries'])
        assert sum(int(r['exits']) for r in part) == int(row['exits']) == int(row['entries'])
        assert close(sum(D(r['invested_sleeve_share']) for r in part) / 17, row['average_invested_sleeve_share'])
        gross = D(keys[(row['strategy'], 'gross_zero_cost')]['cumulative_return'])
        passive = D(keys[('always_long', row['cost_case'])]['cumulative_return'])
        assert close(gross - D(row['cumulative_return']), row['cost_drag_return_difference'])
        assert close(D(row['cumulative_return']) - passive, row['difference_from_always_long'])
    source_hashes = [h for name, h in manifest['input_sha256'].items() if Path(name).name == 'stock_daily.csv']
    assert len(source_hashes) == 1
    now = datetime.now(timezone.utc)
    handoff = dict(status='aggregate_handoff_complete_human_review_pending',
        data_kind='real_benchmark_aggregates_under_modelled_cost_assumptions',
        created_at_utc=now.isoformat(), source_run=RUN_NAME,
        source_run_created_at_utc=manifest['created_at_utc'],
        source_manifest_sha256=original_manifest_hash, source_sha256=source_hashes[0],
        model=manifest['model'], first_entry='2024-06-04', final_exit='2024-06-28',
        source_rows=190, stocks=10, trading_dates=19, holding_intervals_per_stock=17,
        files=manifest['outputs'], table_rows={'performance_summary.csv':6,'daily_portfolio_summary.csv':102},
        code_sha256=manifest['code_sha256'], runtime={'python':manifest['python'],'pandas':manifest['pandas']},
        cost_cases=manifest['cost_cases'], row_level_prices_included=False,
        private_strategy_used=False, raw_or_existing_results_modified=False,
        saved_accounting_checks='passed_again_during_packaging', human_independent_verification='pending',
        limitations=manifest['limitations'],
        intended_use='Independent Project Audible coursework review; redistribution permissions are not asserted')
    payload['handoff_manifest.json'] = (json.dumps(handoff, indent=2) + '\n').encode('utf-8')
    folder = project_root / 'data/semiconductors/benchmark_handoffs'
    folder.mkdir(parents=True, exist_ok=True)
    destination = folder / ('benchmark_results_' + now.strftime('%Y%m%dT%H%M%SZ_') + uuid.uuid4().hex[:8] + '.zip')
    with ZipFile(destination, 'x', ZIP_DEFLATED) as archive:
        for name, data in sorted(payload.items()):
            archive.writestr(name, data)
    with ZipFile(destination) as archive:
        assert archive.testzip() is None
        assert set(archive.namelist()) == set(payload)
        assert all(archive.read(name) == data for name, data in payload.items())
    assert digest(manifest_path) == original_manifest_hash
    for name, expected in manifest['outputs'].items():
        assert digest(run_dir / name) == expected
    for relative, expected in manifest['input_sha256'].items():
        assert digest(project_root / relative) == expected
    print('Summary-only ZIP:', destination)
    print('ZIP SHA256:', digest(destination))
    print('Included: performance_summary.csv (6 rows), daily_portfolio_summary.csv (102 rows), handoff_manifest.json')
    print('Existing inputs/results unchanged. No raw quotes, private strategy or account data exported.')
    return destination

if __name__ == '__main__':
    build_handoff(Path.cwd())
