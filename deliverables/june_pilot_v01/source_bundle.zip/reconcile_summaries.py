"""Read-only reconciliation of released derived summaries. No network or WRDS calls."""
from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
import pandas as pd
from stock_detail_core import reconcile_stock_detail
ROOT=Path(__file__).resolve().parent
for folder,name,key in [('source_summaries','handoff_manifest.json','files'),('stock_source_summaries','stock_detail_manifest.json','outputs')]:
 root=ROOT/'powerbi'/folder
 for n,h in json.loads((root/name).read_text())[key].items():
  assert hashlib.sha256((root/n).read_bytes()).hexdigest()==h, 'Changed input: '+n
p=ROOT/'powerbi/source_summaries';s=ROOT/'powerbi/stock_source_summaries'
summary=pd.read_csv(p/'performance_summary.csv');paths=pd.read_csv(p/'daily_portfolio_summary.csv')
stock=pd.read_csv(s/'stock_performance_summary.csv');stock_paths=pd.read_csv(s/'stock_daily_summary.csv')
assert len(summary)==6 and len(paths)==102 and len(stock)==60 and len(stock_paths)==1020
receipt=reconcile_stock_detail(stock,stock_paths,summary,paths)
q=stock.loc[stock.strategy.eq('lagged_positive_return') & stock.cost_case.eq('quoted_spread_proxy')]
assert q.cumulative_return.gt(0).sum()==4 and q.cumulative_return.lt(0).sum()==6
assert len(q)==10 and q.entries.sum()==49 and q.exits.sum()==49
assert abs(q.average_held_share.mean()-83/170)<1e-12
print(json.dumps(dict(status='released_summary_hashes_and_reconciliation_passed',**receipt,positive_sleeves=4,negative_sleeves=6,files_written=False,network_or_WRDS_queries=False),indent=2))
