# Reproduce the June pilot release

This source-and-summary archive contains no raw price/quote panel or private strategy.

1. Open powerbi/Audible.pbip in Power BI Desktop. Embedded tables need no account.
2. With Python, pandas and numpy installed, run python reconcile_summaries.py here.
   It verifies manifests and reconciles stock contributions/wealth/counts to totals.
3. Run python -W error::FutureWarning -m unittest discover -s benchmark_v02 -p "test_*.py".
   These 23 fictional tests do not verify real source prices or profitability.
4. extraction_source is the earlier source-only scaffold with an unexecuted notebook.
   Its full-history setting is not the June study. Do not pull more data to review this release.
5. For an authorized existing WRDS project with the matching source and audit, copy
   benchmark_v02 there and run python benchmark_v02/run_pilot.py --project-root <project> --check-only.
   No query occurs. Removing --check-only creates a fresh result folder.
6. powerbi/stock_source_summaries/stock_detail_reproduction_cell.py preserves the actual
   WRDS read-only calculation, original run path and source hashes. Inspect paths first.

Documents and validation describe current status. history retains preparation-time
snapshots, whose pending statuses are historical. No source prices or quotes are bundled;
complete raw-to-result replication requires authorized WRDS-side originals. Vendor release
was not recorded; retained file hashes and original pull metadata identify the snapshot.
Shared extraction scaffolding is attributed in extraction_source/docs/source_provenance.json.
