# Public daily benchmark protocol v01

Status: frozen for the first coursework pilot run, not a prospective preregistration. June data and spread summaries already exist; this public rule has not been run on the real June return panel in this session. Do not tune it to support the proposed negative-cost hypothesis.

## Rule and timing

For each of the ten fixed semiconductor sleeves, use the sign of the previous trading day's CRSP RET. If RET(d-1) > 0, hold long during close(d) to close(d+1); otherwise stay in cash. Zero means cash. There is no shorting or leverage. A one-session lag is imposed; exact historical release timestamps are unverified. The quote-based model is not a claim to have obtained an executable closing fill.

With 19 input trading dates, valid entry indices are 1 through 17 (zero-based): 17 holding intervals per stock. First entry is the second calendar date; final liquidation is the last date. All positions begin flat and are liquidated by the fixed end. A signal from the final dates is not traded outside the saved window.

## Capital and comparator

Allocate equal initial capital to ten separate stock sleeves. Keep capital in each sleeve; do not rebalance across stocks every day. Cash earns zero. Compare the rule with always-long sleeves over exactly the same entry/exit window. Return differences from always-long are descriptive comparisons, not risk-adjusted alpha. Lower exposure can explain part of the difference.

## Cost accounting

Use RET(d+1) as the gross close-to-close wealth reference when invested. Daily quotes provide a proportional half-width h(d) = (ask(d)-bid(d))/(ask(d)+bid(d)). This half-width is applied to the wealth reference as an explicit cost assumption; the last trade and quote midpoint may differ.

Let q(d) be the long/cash position. An entry occurs only when q(d)=1 and the prior position was zero. An exit occurs only when q(d)=1 and the next interval's position is zero; terminal liquidation is mandatory. The next position uses information dated d, available before the exit date d+1 under the imposed lag.

For multiplier k:

    factor(d) = (1 + q(d)*RET(d+1))
                / (1 + k*h(d)*entry(d))
                * (1 - k*h(d+1)*exit(d))

Compound factors within each sleeve, then average sleeve wealth using equal initial weights. Consecutive long intervals do not pay artificial round-trip costs at every boundary.

Report all three fixed assumptions: k=0 (gross, optimistic bound), k=1 (quoted-width proxy), k=2 (uncalibrated wider-cost stress). Do not select the assumption that gives the desired result. Gross/net differences are compounded wealth differences, not a literal sum of transaction fees.

## Sample and gates

Use only the existing hashed June 2024 source and original matching audit receipt. The wrapper requires 190 rows, ten labels, 19 calendar dates, no flagged rows and strictly positive bid < ask. It stops for missing dates, duplicate keys, missing-code returns or changed evidence. This fixed-pilot gate is not a general policy to discard unrelated valid data.

The source and audit SHA256 values are embedded from the supplied handoff. The code makes no connection, query, pull, build, order or account call. Check-only mode writes no files. A normal run writes a new UUID-suffixed folder under data/semiconductors/benchmark_runs. Existing raw/build/audit inputs are not overwritten.

## Interpretive limits

This one-month, hindsight-selected pilot tests the pipeline and supports descriptive plots. It does not establish persistent profitability. Do not annualize, report a significance claim, call this actual P&L, or infer that all short-term rules fail. Fees, market impact, taxes, cash yield and intraday latency are omitted. Delisting/loss boundaries are not handled here and trigger review. Source acceptability under the course's primary-source rule remains unresolved.

The strongest available contrary evidence must remain visible, including gross profits, any positive net result, and relative performance against always-long. The hypothesis can fail. Keep the private Trading strategy, selection logic, account data and private results outside this package.

## Reference and validation boundary

The existing saved extraction/audit establishes the local field provenance. WRDS's official variable reference distinguishes bid/ask from bidlo/askhi and labels RET as holding-period return: https://wrds-www.wharton.upenn.edu/demo/crsp/form/ . That public form is a monthly demo, not a substitute for checking the exact daily table metadata on WRDS. Two indexed CRSP guide links returned 404 during this preparation; they were not treated as successfully reviewed full documentation.

Python tests use fictional records only, including temporary fixtures with mocked hashes. Production hash constants are not changed. No real return or profitability result has been computed locally. Human independent formula/number checks and final submission remain pending.

## Compatibility revision v02

The financial rule and all sample/cost assumptions above remain v01. v02 replaces direct DataFrame column assignment with constructor-based normalization and result construction. The runtime module is benchmark_core_v02 to avoid cached v01 imports. Original source/audit hashes remain unchanged. Upstream diagnostic reference: https://github.com/pandas-dev/pandas/issues/61368 . The reported WRDS warning resembles that issue; actual runtime versions must be captured before asserting the precise cause.
