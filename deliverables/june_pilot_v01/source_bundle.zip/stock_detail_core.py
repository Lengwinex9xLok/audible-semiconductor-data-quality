"""Stock-level breakdown of the fixed public benchmark; no network or writes."""
import numpy as np
import pandas as pd

def compute_stock_detail(daily, calendar, core):
    panel, days = core['validate_panel'](daily, calendar)
    groups = list(panel.groupby('permno', sort=True))
    count = len(groups)
    summaries, paths = [], []
    for permno, part in groups:
        part = part.reset_index(drop=True)
        ticker = str(part['pilot_ticker'].iloc[0])
        for strategy in core['STRATEGIES']:
            for case, multiplier in core['COST_CASES'].items():
                sleeve = core['sleeve_path'](part, strategy, multiplier)
                summaries.append(dict(ticker=ticker, strategy=strategy,
                    cost_case=case, spread_multiplier=multiplier,
                    cumulative_return=float(sleeve['wealth'].iloc[-1]-1),
                    initial_portfolio_weight=1/count,
                    holding_intervals=len(sleeve),
                    first_entry=days[1].strftime('%Y-%m-%d'),
                    final_exit=days[-1].strftime('%Y-%m-%d'),
                    average_held_share=float(sleeve['position'].mean()),
                    entries=int(sleeve['entries'].sum()),
                    exits=int(sleeve['exits'].sum())))
                for row in sleeve.itertuples(index=False):
                    paths.append(dict(ticker=ticker, strategy=strategy,
                        cost_case=case, spread_multiplier=multiplier,
                        entry_date=pd.Timestamp(row.entry_date).strftime('%Y-%m-%d'),
                        date=pd.Timestamp(row.date).strftime('%Y-%m-%d'),
                        wealth=float(row.wealth), position=int(row.position),
                        entries=int(row.entries), exits=int(row.exits)))
    gross = {(s['ticker'],s['strategy']):s['cumulative_return'] for s in summaries if s['cost_case']=='gross_zero_cost'}
    passive = {(s['ticker'],s['cost_case']):s['cumulative_return'] for s in summaries if s['strategy']=='always_long'}
    summaries = [dict(s,
        cost_drag_return_difference=gross[(s['ticker'],s['strategy'])]-s['cumulative_return'],
        contribution_to_portfolio_return=s['initial_portfolio_weight']*s['cumulative_return'],
        difference_from_stock_always_long=s['cumulative_return']-passive[(s['ticker'],s['cost_case'])]) for s in summaries]
    return pd.DataFrame(summaries),pd.DataFrame(paths)

def reconcile_stock_detail(detail, paths, saved_summary, saved_paths):
    assert not detail.duplicated(['ticker','strategy','cost_case']).any()
    assert not paths.duplicated(['ticker','strategy','cost_case','date']).any()
    for ref in saved_summary.itertuples(index=False):
        s=detail.loc[detail.strategy.eq(ref.strategy)&detail.cost_case.eq(ref.cost_case)]
        assert len(s)==ref.stocks and s.ticker.nunique()==ref.stocks
        assert s.holding_intervals.eq(ref.holding_intervals).all()
        assert np.isclose(s.contribution_to_portfolio_return.sum(),ref.cumulative_return,atol=1e-12,rtol=0)
        assert np.isclose(s.average_held_share.mean(),ref.average_invested_sleeve_share,atol=1e-12,rtol=0)
        assert np.isclose(s.cost_drag_return_difference.mean(),ref.cost_drag_return_difference,atol=1e-12,rtol=0)
        assert np.isclose(s.difference_from_stock_always_long.mean(),ref.difference_from_always_long,atol=1e-12,rtol=0)
        assert s.entries.sum()==ref.entries and s.exits.sum()==ref.exits
    for ref in saved_paths.itertuples(index=False):
        p=paths.loc[paths.strategy.eq(ref.strategy)&paths.cost_case.eq(ref.cost_case)&paths.date.eq(ref.date)]
        assert len(p)==detail.ticker.nunique()
        assert np.isclose(p.wealth.mean(),ref.wealth,atol=1e-12,rtol=0)
        assert np.isclose(p.position.mean(),ref.invested_sleeve_share,atol=1e-12,rtol=0)
        assert p.entries.sum()==ref.entries and p.exits.sum()==ref.exits
    return dict(summary_cases_checked=len(saved_summary),portfolio_dates_checked=len(saved_paths))
