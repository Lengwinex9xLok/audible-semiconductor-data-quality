from pathlib import Path
import json,re,hashlib
import pandas as pd
from xml.sax.saxutils import escape
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,PageBreak,Preformatted
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib import colors
from pypdf import PdfReader
R=Path(__file__).resolve().parent;D=R/'documents';D.mkdir(exist_ok=True)
position='''Keep the public timing rule in research
To: Project Audible review panel
From: Loki Ziye
Date: October 26, 2026 | Dashboard v09 | Memo revision 2

I recommend keeping this public short-horizon rule in research rather than trading it on the current evidence. It earns 76.35% gross in 2025, but matching starting stock allocations reduces its advantage over passive exposure from 10.60 to 1.93 percentage points. Its lower drawdown is meaningful counterevidence to my recommendation. Unequal market exposure and an unresolved transaction-cost input still prevent a reliable after-cost decision.

The decision and comparison
The question is whether a retail trader should use this short-horizon timing rule instead of passive exposure to the same semiconductor stocks. Both views have a plausible case: timing may improve the holding path or reduce losses, while passive exposure avoids frequent trades and can capture a strong industry market. This small public-rule study informs that decision; it does not test a private trading strategy or settle the literature.

The rule holds close(d) to close(d+1) if RET(d-1)>0, otherwise cash. Ten stock sleeves begin equally funded in December 2021, retain their capital and are never rebalanced across stocks within the continuous rule. The new annual passive comparator starts with the rule's actual weights at that year's start. This removes an initial-allocation difference; it does not equalize market risk or cash exposure.

[COMPARISON_TABLE]

Values are gross cumulative percentages; gaps are percentage points. Each annual matched comparator is a separate conditional benchmark. Its annual returns must not be compounded as one continuously implementable strategy. The full-period comparison begins with equal weights for both paths.

In 2025 the public rule returns 76.35%. The original passive portfolio returns 65.75%, while the same-starting-weight passive comparator returns 74.42%. Thus 8.67 of the original 10.60 percentage points, about 82%, comes from different starting allocations. The remaining 1.93 percentage points describes different holding paths, including cash timing. It is not an estimate of alpha.

===PAGE===
The strongest evidence against the recommendation
The strongest objection is that 2025 is favorable even after matching allocations. The public rule gains 76.35% gross against 74.42%, and its within-year daily-close maximum drawdown is 18.21%, compared with 29.76% for the matched passive portfolio. Its mean beginning-of-interval invested-dollar exposure is 54.95%. These results are retained, rather than dismissing a strong year as merely an AI boom. Different exposure still prevents a risk-neutral comparison.

Attribution shows what the returns contain. MU, LRCX and KLAC account for 49.01% of positive stock contributions to the public rule's 2025 gross return. Monthly increments to the matched-comparison gap are especially positive in November (+14.63 percentage points) and April (+8.54), but negative in October (-8.22) and December (-8.18). Those increments are measured against period-start capital and sum to the annual gap. They are not simple monthly percentage returns or a causal decomposition of AI news.

The wider sample also matters. The matched-comparison gap is +5.35 pp in 2022, -43.32 pp in 2023, -2.58 pp in 2024 and +1.93 pp in 2025. Over 2022-2025 the public rule earns 71.40% gross against 125.92% for passive exposure from the same original allocation. Different cash exposure and zero cash yield prevent these gaps from establishing risk-adjusted superiority or inferiority. A favorable year does not establish persistence.

The largest limitation and next decision
The main barrier to an after-cost conclusion is explicit. ADI has a crossed closing quote on April 16, 2025 at a required cost event, corroborated in the underlying CIZ table. The frozen net calculator stops; no row or quote is repaired, swapped or dropped. Consequently this release reports gross results only. Fees, market impact, taxes, intraday delays, actual fills and cash yield are not measured. Available annual CRSP coverage ends December 2025; newer-frequency libraries deny this account access.

The stocks were selected in 2026, and the attribution design followed inspection of the historical results. This is retrospective analysis of a convenience universe, not prospective validation. My research-only position rests on unresolved costs, exposure differences and limited independent validation, not on a requirement that every year lose money. I would reconsider it after a documented quote resolution or a separate cost sensitivity specified before seeing its net result, followed by validation on a separately specified sample with fixed rules and explicit exposure and cash assumptions.

Evidence: comparison_summary.csv; stock_attribution.csv; monthly_attribution.csv; comparison_paths.csv; protocol.json; Power BI v09 pages 1-3. This AI-assisted draft is for student review; no new human verification is claimed.
'''
technical='''Methods for the semiconductor rule comparison
To: Project Audible review panel
From: Loki Ziye
Date: October 26, 2026 | Dashboard v09 | Memo revision 2

Source and scope
This analysis uses only derived summary tables already produced from programmatic WRDS CIZ data. The upstream source is crsp_a_stock.dsf_v2, with dated stocknames_v2 identity checks and wrds_dailyindexret_query for the source-relative calendar. The upstream snapshot was pulled October 26, 2026, covers December 30, 2021 through December 31, 2025, and contains 10,050 rows: 20 warmup records and 10,030 analysis stock-date observations. There are 1,003 holding intervals per stock. Source manifests preserve hashes; a vendor release identifier was not recorded.

The ten saved PERMNOs identify ADI, AMAT, AMD, INTC, KLAC, LRCX, MU, NVDA, QCOM and TXN. This 2026 convenience universe is not a historical S&P 500 portfolio; membership is not an exclusion rule. All three named sources were accessed through WRDS SQL on October 26, 2026, selecting saved securities and dates. CIZ/Version 2 names the source format; hashes pin the snapshot, not a known vendor release. No broker, account, private Trading or group file is used.

CIZ replaces the discontinued legacy SIZ format. The entire new 2022-2025 run uses CIZ, with no splice to legacy returns. Across 2,520 overlapping 2024 records, the largest absolute differences are 0.000001 for RET/RETX and 0.00006 for bid/ask; no 2024 positive-return signal signs differ. The accessible annual CIZ source ends December 2025. Monthly and quarterly schemas denied access, so no 2026 observation or return is inferred.

From source records to gross wealth
Rows are matched to dated names by PERMNO and valid name dates, then checked against the source calendar. The source audit reports 10,050 dated-name matches, zero previous-date mismatches and no missing numeric values. The calculation rejects duplicate keys, ambiguous identities, missing/unexpected dates, invalid numerics and nonpositive quotes. Quality flags are retained. Map dlycaldt to date, dlyret/dlyretx to RET/RETX and dlybid/dlyask to bid/ask.

The public rule holds an interval close(d) to close(d+1) when RET(d-1)>0. Otherwise it holds cash at zero yield. The first entry date is December 31, 2021. No shorting, leverage or daily/annual cross-stock rebalance is added to the original path. The original sleeve_path engine is unchanged. Two summary inputs contain period-normalized stock wealth paths, binary holding positions and actual period-start capital weights.

The source has 15 locked and three crossed quotes, including six required locked events and one required crossed ADI event. A complete 2025/four-year net calculation is rejected. The gross-only adapter permits crossed quotes only when every cost multiplier is zero. It neither repairs quotes nor creates net returns. Locked quotes do not establish free execution. The older 2022-2024 cost release is a separate source/window.

===PAGE===
Matched comparator and exact decomposition
For each selected period let a_i be the public rule's actual starting capital weight and b_i the original passive portfolio's starting weight. Let A_i(t) and B_i(t) be their gross stock-sleeve wealth paths normalized to one at that period's start. The three portfolio paths are:

[FORMULAS]

These definitions use only starting weights and the saved holding paths. The matched passive benchmark remains fully invested in those stocks; it is not volatility-matched, beta-neutral or dollar-exposure-matched. Annual benchmarks each begin at the selected year's public weights, then hold them without cross-stock rebalancing within that year. They are independent conditional comparisons. Their annual returns are not a compoundable continuous comparator.

Stock attribution uses a_i times the public sleeve return for public contribution, a_i times the passive sleeve return for matched-passive contribution, and a_i times their difference for holding-path contribution. Initial-allocation contribution is (a_i-b_i) times the passive sleeve return. The corresponding stock terms sum to portfolio returns and the two exact gap terms. These are accounting descriptions, not causal effects or estimates of alpha.

Monthly contribution and risk
A month's contribution to the selected-period return is the change in normalized portfolio wealth between adjacent month ends. Its public-minus-matched increment telescopes exactly to the selected-period holding-path difference. A stock's increment uses a_i times its wealth change over that month. Separately, contribution to that month's own return divides the increment by actual month-start portfolio wealth. Simple monthly percentage returns are compounded, not added.

Mean invested-dollar exposure averages sum_i[a_i*A_i(t-1)*q_i(t)] divided by public portfolio wealth before the interval. It uses previous wealth, never the same interval's realized return. It differs from the share of stock sleeves held. Maximum drawdown uses wealth/running maximum wealth minus one and includes the initial wealth of one. It is a daily-close, within-period statistic; intraday drawdowns are unobserved. The top-three concentration measure uses the three largest positive stock contributions divided by all positive contributions, and is blank if no contributions are positive.

===PAGE===
Reproduction and validation
Extract deliverables/attribution_v01/source_bundle.zip into a fresh directory. It includes code, two derived summary inputs, protocols, five result CSVs and editable Power BI sources. Python, pandas and NumPy are required. From the extracted directory run:

[COMMANDS]

The runner rejects an existing output folder and verifies the included input hashes. A clean archive replay reproduced all five CSVs byte for byte. This checks attribution from saved summaries, not upstream retrieval from licensed raw data. Raw files remain on WRDS. The original upstream runtime was Python 3.14.5/pandas 2.2.3; the memo validation receipt records the local replay runtime.

Tests cover a hand-derived two-stock allocation decomposition, equal-weight identity, monthly additivity versus compounding, exposure based on previous wealth, initial-wealth drawdown, missing dates, invalid weights, nonzero-cost source rejection, inconsistent positions/returns and input preservation. Runtime checks also reconstruct each active sleeve's gross interval factor from the passive interval return and the saved holding position. Stock contributions, monthly increments, gap components and monthly compounding reconcile to portfolio totals. Downloaded input and original artifact hashes are rechecked. These are AI-assisted software/accounting checks, not independent human validation.

Design choices and rejected alternatives
Matching starting stock weights addresses a specific confound in the earlier annual comparison. It leaves exposure differences visible rather than calling them controlled. The original passive comparator is retained so readers can see the allocation effect. No ex-post leverage scaling is fitted to the observed return or volatility. There is no random-timing experiment, regression alpha, significance claim, optimal parameter search or causal AI-event attribution in this release. More elaborate tests would require a separately specified design.

The 2025 aggregate and stock results were known before this attribution protocol. Its results cannot be described as preregistered or out of sample. The initial protocol is retained; a later portability update changes file paths and hashes only, without changing financial or attribution rules. A current source hash is stronger provenance than an unsupported claim about a vendor release version.

Dashboard and course boundaries
Download the separate Audible_Semiconductor_v09.pbix; it embeds data and needs no WRDS connection. Its three pages cover the decision, attribution/counterevidence and stock detail. Each has an independent period control defaulting to 2025. Page 1 annual bars show all four years; other visuals follow the page's period. Select a year for all twelve monthly columns. The PBIX was reopened and all three pages, a 2025/2024/2025 switch and MU detail were checked. Drill-through was checked earlier in PBIP, not repeated at export; Ctrl-click Back was not separately tested.

The original source ZIP is retained with its earlier memo drafts. The separate PDFs/text beside the v09 PBIX are the current revision. Instructor acceptance of CRSP as the intended primary source, the narrowed controversy and the lecture's two-person team arrangement remains unconfirmed; separate group-topic approval does not resolve these items.

LLM ownership and evidence
Loki chose the privacy boundary and requested comparable allocations and attribution. AI authored the code, DAX, charts and draft prose, and performed software, arithmetic and render checks. The LLM log records the prompts, outputs and corrections; student verification of this CIZ expansion and final position remains pending. The earlier user-reported June arithmetic check does not verify these new results. The strongest favorable 2025 evidence remains visible alongside the recommendation.
'''
(D/'position_memo.txt').write_text(position,encoding='utf-8');(D/'technical_memo.txt').write_text(technical,encoding='utf-8')
s=getSampleStyleSheet()
for st in [ParagraphStyle(name='AT',fontName='Helvetica-Bold',fontSize=17,leading=20,spaceAfter=8),ParagraphStyle(name='AB',fontName='Helvetica',fontSize=10.0,leading=13.1,spaceAfter=8),ParagraphStyle(name='AH',fontName='Helvetica-Bold',fontSize=11.4,leading=14,spaceBefore=4,spaceAfter=7),ParagraphStyle(name='AM',fontName='Helvetica',fontSize=8.8,leading=11.5,spaceAfter=9,textColor=colors.HexColor('#444444')),ParagraphStyle(name='AC',fontName='Courier',fontSize=8.8,leading=12,spaceAfter=10)]:s.add(st)
def p(t,style='AB'):return Paragraph(escape(t).replace('\n','<br/>'),s[style])
heads={'The decision and comparison','The strongest evidence against the recommendation','The largest limitation and next decision','Source and scope','From source records to gross wealth','Matched comparator and exact decomposition','Monthly contribution and risk','Reproduction and validation','Design choices and rejected alternatives','Dashboard and course boundaries','LLM ownership and evidence'}
S=pd.read_csv(R/'results/comparison_summary.csv',dtype={'period':str})
def footer(c,doc):
 c.setFont('Helvetica',8);c.setFillColor(colors.HexColor('#666666'));c.drawString(50,30,'Project Audible | v09 gross comparison | Memo revision 2 | Student review draft');c.drawRightString(562,30,str(doc.page))
def build(name,count):
 text=(D/(name+'.txt')).read_text();lines=text.splitlines();story=[p(lines[0],'AT'),p(' | '.join(lines[1:4]),'AM')]
 for block in re.split(r'\n\s*\n','\n'.join(lines[4:]).strip()):
  if block.startswith('===PAGE==='):story.append(PageBreak());block=block.removeprefix('===PAGE===').strip()
  if not block:continue
  parts=block.splitlines()
  if parts[0] in heads:story.append(p(parts[0],'AH'));block='\n'.join(parts[1:]).strip()
  if not block:continue
  if block=='[COMPARISON_TABLE]':
   rows=[['Period','Public gross','Matched passive','Holding gap (pp)']]
   for period in ['2022','2023','2024','2025','All']:
    r=S.set_index('period').loc[period];rows.append(['2022-2025' if period=='All' else period,f'{r.public_return*100:+.2f}%',f'{r.matched_passive_return*100:+.2f}%',f'{r.holding_path_difference*100:+.2f}'])
   t=Table(rows,colWidths=[95,132,145,140]);t.setStyle(TableStyle([('FONTNAME',(0,0),(-1,0),'Helvetica-Bold'),('FONTNAME',(0,1),(-1,-1),'Helvetica'),('FONTSIZE',(0,0),(-1,-1),9),('ALIGN',(1,0),(-1,-1),'RIGHT'),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6),('LINEBELOW',(0,0),(-1,0),.5,colors.HexColor('#999999')),('LINEBELOW',(0,-1),(-1,-1),.4,colors.HexColor('#bbbbbb'))]));story.extend([t,Spacer(1,10)])
  elif block=='[COMMANDS]':story.append(Preformatted("python -m unittest discover -s code -p 'test*.py'\npython code/attribution.py --output-name memo_review_results",s['AC']))
  elif block=='[FORMULAS]':story.append(Preformatted('Public(t) = sum_i a_i * A_i(t)\nMatched(t) = sum_i a_i * B_i(t)\nOriginalPassive(t) = sum_i b_i * B_i(t)\n\nPublic(T)-OriginalPassive(T)\n  = [Public(T)-Matched(T)] + [Matched(T)-OriginalPassive(T)]',s['AC']))
  else:story.append(p(block,'AM' if block.startswith('Evidence:') else 'AB'))
 doc=SimpleDocTemplate(str(D/(name+'.pdf')),pagesize=(612,792),leftMargin=50,rightMargin=50,topMargin=42,bottomMargin=48,title=lines[0],author='Loki Ziye')
 doc.build(story,onFirstPage=footer,onLaterPages=footer)
 pages=len(PdfReader(D/(name+'.pdf')).pages);assert pages==count,(name,pages)
 return dict(file=name+'.pdf',pages=pages)
print(json.dumps([build('position_memo',2),build('technical_memo',3)],indent=2))

