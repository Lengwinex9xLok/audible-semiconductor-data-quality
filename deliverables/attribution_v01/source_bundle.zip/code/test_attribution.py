import unittest
import numpy as np
import pandas as pd
from attribution import analyze,drawdown,PUBLIC,PASSIVE

def fixture(equal_weights=False):
    dates=['2023-12-29','2024-01-02','2024-02-01']
    paths=[];summary=[]
    values={PUBLIC:{'A':[1.,1.,1.1],'B':[1.,.8,.8]},PASSIVE:{'A':[1.,1.2,1.32],'B':[1.,.8,.88]}}
    positions={PUBLIC:{'A':[None,0,1],'B':[None,1,0]},PASSIVE:{'A':[None,1,1],'B':[None,1,1]}}
    for strategy in [PUBLIC,PASSIVE]:
        for i,ticker in enumerate(['A','B']):
            w=[.75,.25] if strategy==PUBLIC or equal_weights else [.25,.75]
            summary.append(dict(period='2024',ticker=ticker,strategy=strategy,cost_case='gross_zero_cost',cumulative_return=values[strategy][ticker][-1]-1,initial_portfolio_weight=w[i]))
            for j,date in enumerate(dates):paths.append(dict(period='2024',ticker=ticker,strategy=strategy,cost_case='gross_zero_cost',date=date,wealth=values[strategy][ticker][j],position=positions[strategy][ticker][j],is_initial=int(j==0)))
    return pd.DataFrame(summary),pd.DataFrame(paths)

class AttributionTests(unittest.TestCase):
    def test_known_decomposition(self):
        s,p=fixture();out=analyze(s,p);r=out['comparison_summary'].iloc[0]
        self.assertAlmostEqual(r.public_return,.025)
        self.assertAlmostEqual(r.matched_passive_return,.21)
        self.assertAlmostEqual(r.original_passive_return,-.01)
        self.assertAlmostEqual(r.holding_path_difference,-.185)
        self.assertAlmostEqual(r.initial_allocation_difference,.22)
        self.assertAlmostEqual(r.original_difference,.035)
    def test_equal_weights_no_allocation_effect(self):
        s,p=fixture(True);r=analyze(s,p)['comparison_summary'].iloc[0]
        self.assertAlmostEqual(r.initial_allocation_difference,0)
    def test_monthly_increments_telescope(self):
        s,p=fixture();o=analyze(s,p);m=o['monthly_attribution'];sm=o['stock_monthly_attribution']
        self.assertAlmostEqual(m.public_period_increment.sum(),.025)
        self.assertAlmostEqual(sm.public_contribution_to_period_return.sum(),.025)
        self.assertAlmostEqual(m.holding_path_gap_increment.sum(),-.185)
        self.assertAlmostEqual((1+m.public_month_return).prod()-1,.025)
        self.assertFalse(np.isclose(m.public_month_return.sum(),.025))
    def test_exposure_uses_previous_wealth(self):
        s,p=fixture();r=analyze(s,p)['comparison_summary'].iloc[0]
        self.assertAlmostEqual(r.average_public_dollar_exposure,(.25+.75/.95)/2)
        self.assertAlmostEqual(r.average_held_name_share,.5)
    def test_drawdown_includes_initial_cash(self):
        r,dd=drawdown([1,.9,.8,.95,1.1],list('abcde'))
        self.assertAlmostEqual(r['max_drawdown'],-.2)
        self.assertEqual(r['peak_date'],'a');self.assertEqual(r['trough_date'],'c');self.assertEqual(r['recovery_date'],'e')
    def test_missing_date_rejected(self):
        s,p=fixture()
        with self.assertRaises((ValueError,AssertionError)):analyze(s,p.drop(index=1))
    def test_bad_weights_rejected(self):
        s,p=fixture();s.loc[0,'initial_portfolio_weight']=.9
        with self.assertRaisesRegex(ValueError,'sum'):analyze(s,p)
    def test_nonzero_cost_source_rejected(self):
        s,p=fixture();p.loc[0,'cost_case']='quoted_spread_proxy'
        with self.assertRaisesRegex(ValueError,'Gross'):analyze(s,p)
    def test_wrong_position_or_return_rejected(self):
        s,p=fixture();p.loc[1,'position']=1
        with self.assertRaises(AssertionError):analyze(s,p)
    def test_input_immutability(self):
        s,p=fixture();s0=s.copy(deep=True);p0=p.copy(deep=True);analyze(s,p)
        pd.testing.assert_frame_equal(s,s0);pd.testing.assert_frame_equal(p,p0)

if __name__=='__main__':unittest.main()
