"""Summary-only attribution. No market query, private strategy or order access."""
from pathlib import Path
import hashlib,json
import numpy as np
import pandas as pd

PUBLIC='lagged_positive_return'
PASSIVE='always_long'

def drawdown(wealth,dates):
    w=np.asarray(wealth,float);dates=list(dates)
    if len(w)!=len(dates) or not np.isfinite(w).all() or (w<=0).any():raise ValueError('Invalid wealth path')
    dd=w/np.maximum.accumulate(w)-1
    trough=int(np.argmin(dd));peak=int(np.argmax(w[:trough+1]))
    recovery=next((dates[j] for j in range(trough+1,len(w)) if w[j]>=w[peak]),None) if dd[trough]<0 else dates[0]
    return dict(max_drawdown=float(dd[trough]),peak_date=dates[peak],trough_date=dates[trough],recovery_date=recovery),dd

def analyze(stock_summary,stock_paths):
    required={'period','ticker','strategy','cost_case','cumulative_return','initial_portfolio_weight'}
    if not required.issubset(stock_summary):raise ValueError('Missing summary columns')
    if not {'period','ticker','strategy','cost_case','date','wealth','position','is_initial'}.issubset(stock_paths):raise ValueError('Missing path columns')
    if set(stock_summary.cost_case)!={'gross_zero_cost'} or set(stock_paths.cost_case)!={'gross_zero_cost'}:raise ValueError('Gross inputs only')
    if set(stock_summary.strategy)!={PUBLIC,PASSIVE}:raise ValueError('Both strategies required')
    if stock_summary.duplicated(['period','ticker','strategy']).any() or stock_paths.duplicated(['period','ticker','strategy','date']).any():raise ValueError('Duplicate key')
    summaries=[];paths=[];stocks=[];months=[];stock_months=[]
    periods=(['All'] if 'All' in set(stock_summary.period) else [])+sorted(set(stock_summary.period)-{'All'})
    for period in periods:
        ds=stock_summary.loc[stock_summary.period.eq(period)]
        pp=stock_paths.loc[stock_paths.period.eq(period)]
        sa=ds.loc[ds.strategy.eq(PUBLIC)].set_index('ticker').sort_index()
        sb=ds.loc[ds.strategy.eq(PASSIVE)].set_index('ticker').sort_index()
        if not sa.index.equals(sb.index) or len(sa)==0:raise ValueError('Different stock universes')
        names=list(sa.index)
        ap=pp.loc[pp.strategy.eq(PUBLIC)].pivot(index='date',columns='ticker',values='wealth').sort_index().reindex(columns=names)
        bp=pp.loc[pp.strategy.eq(PASSIVE)].pivot(index='date',columns='ticker',values='wealth').sort_index().reindex(columns=names)
        pos=pp.loc[pp.strategy.eq(PUBLIC)].pivot(index='date',columns='ticker',values='position').sort_index().reindex(columns=names)
        initial=pp.loc[pp.strategy.eq(PUBLIC)].groupby('date').is_initial.agg(['min','max']).reindex(ap.index)
        if not ap.index.equals(bp.index) or not ap.index.equals(pos.index) or len(ap)<2:raise ValueError('Different/missing dates')
        if initial.iloc[0].tolist()!=[1,1] or not initial.iloc[1:].eq(0).all().all():raise ValueError('Invalid initial-row markers')
        aa,bb=ap.to_numpy(float),bp.to_numpy(float);q=pos.iloc[1:].to_numpy(float)
        a=sa.initial_portfolio_weight.to_numpy(float);b=sb.initial_portfolio_weight.to_numpy(float)
        if not np.isfinite(np.r_[aa.ravel(),bb.ravel(),a,b]).all() or (aa<=0).any() or (bb<=0).any() or (a<0).any() or (b<0).any():raise ValueError('Nonfinite or invalid inputs')
        if not np.isclose(a.sum(),1,atol=1e-12,rtol=0) or not np.isclose(b.sum(),1,atol=1e-12,rtol=0):raise ValueError('Weights must sum to one')
        if not np.isin(q,[0,1]).all():raise ValueError('Positions must be binary')
        np.testing.assert_allclose(aa[0],1,atol=1e-12,rtol=0);np.testing.assert_allclose(bb[0],1,atol=1e-12,rtol=0)
        # The passive wealth ratios identify the same underlying gross interval return.
        np.testing.assert_allclose(aa[1:]/aa[:-1],1+q*(bb[1:]/bb[:-1]-1),atol=1e-12,rtol=0)
        np.testing.assert_allclose(aa[-1]-1,sa.cumulative_return,atol=1e-12,rtol=0)
        np.testing.assert_allclose(bb[-1]-1,sb.cumulative_return,atol=1e-12,rtol=0)
        va=aa@a;vm=bb@a;vo=bb@b
        # These dollar exposures use wealth BEFORE the interval, never same-day return.
        exposure=((aa[:-1]*a*q).sum(axis=1))/va[:-1]
        risk_a,dda=drawdown(va,ap.index);risk_m,ddm=drawdown(vm,ap.index);risk_o,ddo=drawdown(vo,ap.index)
        ra,rm,ro=float(va[-1]-1),float(vm[-1]-1),float(vo[-1]-1)
        holding=ra-rm;allocation=rm-ro;original=ra-ro
        assert np.isclose(original,holding+allocation,atol=1e-12,rtol=0)
        positive=a*(aa[-1]-1);positive=positive[positive>0]
        summaries.append(dict(period=period,public_return=ra,matched_passive_return=rm,original_passive_return=ro,holding_path_difference=holding,initial_allocation_difference=allocation,original_difference=original,public_max_drawdown=risk_a['max_drawdown'],matched_passive_max_drawdown=risk_m['max_drawdown'],original_passive_max_drawdown=risk_o['max_drawdown'],average_public_dollar_exposure=float(exposure.mean()),average_held_name_share=float(q.mean()),top3_share_of_positive_contributions=float(np.sort(positive)[-3:].sum()/positive.sum()) if len(positive) else None,stocks=len(a),holding_intervals=len(ap)-1,first_entry=str(ap.index[0]),final_exit=str(ap.index[-1]),public_drawdown_peak=risk_a['peak_date'],public_drawdown_trough=risk_a['trough_date'],public_drawdown_recovery=risk_a['recovery_date'],net_status='Unavailable under frozen quote policy for full window / 2025; all values here gross'))
        for j,date in enumerate(ap.index):
            paths.append(dict(period=period,date=date,public_wealth=float(va[j]),matched_passive_wealth=float(vm[j]),original_passive_wealth=float(vo[j]),public_drawdown=float(dda[j]),matched_passive_drawdown=float(ddm[j]),public_dollar_exposure=None if j==0 else float(exposure[j-1]),is_initial=int(j==0)))
        for i,ticker in enumerate(names):
            r1=float(aa[-1,i]-1);r2=float(bb[-1,i]-1)
            stocks.append(dict(period=period,ticker=ticker,public_stock_return=r1,passive_stock_return=r2,public_start_weight=float(a[i]),original_passive_start_weight=float(b[i]),public_contribution=float(a[i]*r1),matched_passive_contribution=float(a[i]*r2),holding_path_contribution=float(a[i]*(r1-r2)),initial_allocation_contribution=float((a[i]-b[i])*r2)))
        # Initial baseline is excluded when identifying months of realized return.
        previous=0
        date_array=np.asarray(ap.index)
        for month in sorted(set(str(x)[:7] for x in ap.index[1:])):
            indexes=[j for j,x in enumerate(ap.index) if j>0 and str(x).startswith(month)]
            end=indexes[-1]
            month_ra=float(va[end]/va[previous]-1);month_rm=float(vm[end]/vm[previous]-1)
            inc_a=float(va[end]-va[previous]);inc_m=float(vm[end]-vm[previous])
            months.append(dict(period=period,month=month,date=str(ap.index[end]),public_month_return=month_ra,matched_passive_month_return=month_rm,public_period_increment=inc_a,matched_passive_period_increment=inc_m,holding_path_gap_increment=inc_a-inc_m,holding_intervals=len(indexes)))
            for i,ticker in enumerate(names):
                delta_a=float(a[i]*(aa[end,i]-aa[previous,i]));delta_m=float(a[i]*(bb[end,i]-bb[previous,i]))
                stock_months.append(dict(period=period,ticker=ticker,month=month,date=str(ap.index[end]),public_contribution_to_month_return=delta_a/va[previous],matched_contribution_to_month_return=delta_m/vm[previous],public_contribution_to_period_return=delta_a,matched_contribution_to_period_return=delta_m,holding_path_gap_increment=delta_a-delta_m))
            previous=end
    return dict(comparison_summary=pd.DataFrame(summaries),comparison_paths=pd.DataFrame(paths),stock_attribution=pd.DataFrame(stocks),monthly_attribution=pd.DataFrame(months),stock_monthly_attribution=pd.DataFrame(stock_months))

def run(root,output_name="results"):
    root=Path(root).resolve();base=root.parents[1];protocol=json.loads((root/'protocol.json').read_text())
    for rel,h in protocol['inputs'].items():
        if (base/rel).is_file():assert hashlib.sha256((base/rel).read_bytes()).hexdigest()==h,rel
    source=root/'inputs'
    for n,h in protocol['source_tables'].items():assert hashlib.sha256((source/n).read_bytes()).hexdigest()==h,n
    ds=pd.read_csv(source/'stock_performance_summary.csv',dtype={'period':str})
    pp=pd.read_csv(source/'stock_daily_summary.csv',dtype={'period':str})
    out=analyze(ds,pp)
    if not output_name.isidentifier():raise ValueError('Use a new simple output directory name')
    dest=root/output_name;dest.mkdir(exist_ok=False)
    for n,t in out.items():t.to_csv(dest/(n+'.csv'),index=False,mode='x')
    # Independently reconcile additive monthly increments and both gap components.
    for r in out['comparison_summary'].itertuples():
        st=out['stock_attribution'].query('period==@r.period')
        mo=out['monthly_attribution'].query('period==@r.period')
        sm=out['stock_monthly_attribution'].query('period==@r.period')
        for table,col,value in [(st,'public_contribution',r.public_return),(st,'matched_passive_contribution',r.matched_passive_return),(st,'holding_path_contribution',r.holding_path_difference),(st,'initial_allocation_contribution',r.initial_allocation_difference),(mo,'public_period_increment',r.public_return),(mo,'matched_passive_period_increment',r.matched_passive_return),(mo,'holding_path_gap_increment',r.holding_path_difference),(sm,'public_contribution_to_period_return',r.public_return)]:
            assert np.isclose(table[col].sum(),value,atol=1e-12,rtol=0)
        assert np.isclose((1+mo.public_month_return).prod()-1,r.public_return,atol=1e-12,rtol=0)
        assert np.isclose((1+mo.matched_passive_month_return).prod()-1,r.matched_passive_return,atol=1e-12,rtol=0)
        assert np.isclose(sm.groupby('month').public_contribution_to_month_return.sum(),mo.set_index('month').public_month_return,atol=1e-12,rtol=0).all()
    for rel,h in protocol['inputs'].items():
        if (base/rel).is_file():assert hashlib.sha256((base/rel).read_bytes()).hexdigest()==h,rel
    manifest=dict(status='summary_only_attribution_complete',protocol_sha256=hashlib.sha256((root/'protocol.json').read_bytes()).hexdigest(),tables={n:len(t) for n,t in out.items()},outputs={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in dest.iterdir()},old_input_hashes_unchanged=sum((base/p).is_file() for p in protocol['inputs']),raw_source_or_private_data_read=False,network_queries=False,costs='gross only',financial_rule_changed=False,comparator_years_are_independent=True,causal_AI_attribution_or_alpha_claim=False)
    (dest/'analysis_manifest.json').write_text(json.dumps(manifest,indent=2))
    print(out['comparison_summary'][['period','public_return','matched_passive_return','original_passive_return','holding_path_difference','initial_allocation_difference','public_max_drawdown','matched_passive_max_drawdown','average_public_dollar_exposure']].to_string(index=False))
    return out
if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--output-name',default='results')
    run(Path(__file__).resolve().parents[1],parser.parse_args().output_name)


