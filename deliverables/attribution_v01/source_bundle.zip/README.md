# Comparable allocations and attribution

Open powerbi/Audible.pbip in Power BI Desktop. This embeds derived summary data and
requires no WRDS or broker connection. Refresh if Desktop requests it. Each page
has its own period control, default 2025; a cleared control also falls back to 2025.
Page 1 annual bars always show all four years. Page 2 shows stock/month attribution
and daily drawdown. Right-click a stock column, Drill through > 03 Stock detail;
choose the period on that page separately. MU is the saved stock. The Back binding
is retained; Ctrl-click was not separately exercised.

All new values are gross. A required crossed quote blocks the full new net estimate.
Each annual matched passive comparator starts with that year's public weights;
annual matched returns are separate comparisons, not one continuous strategy.
Select a year to see all 12 monthly columns; Full may require horizontal scrolling.
This is accounting attribution, not causal AI attribution or a risk-neutral comparison.

Reproduce with Python, pandas and NumPy:

```sh
python -m unittest discover -s code -p 'test*.py'
python code/attribution.py --output-name fresh_results
```

The runner rejects an existing output folder. Source table hashes are verified;
new results should match the five supplied result CSVs. It needs no market query.
The protocol's original workspace artifact hashes document preservation; portable
replays verify the two included summary inputs and any original artifacts present.

The original group project and private Trading data are outside this package.
This coursework draft requires student review. See docs/rubric_check.md for source,
topic and teams-of-two questions that still need instructor confirmation.

The retained initial analysis_manifest.json explicitly hashes protocol_initial.json.
Portable replays use protocol.json with the added source-table paths and hashes;
financial and attribution definitions are identical. Both protocols are retained.
